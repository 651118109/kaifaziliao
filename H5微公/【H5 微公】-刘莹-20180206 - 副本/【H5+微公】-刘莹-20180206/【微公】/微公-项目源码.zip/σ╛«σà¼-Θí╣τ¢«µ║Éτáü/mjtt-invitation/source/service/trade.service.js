/**
 * Created by allen on 2017/4/7.
 */

import Trade from '../models/trade';
import {ConstCode} from '../util/const';
import {ERRCODE} from '../util/errcode';
import DBHelper from '../db/mysql.connector';

class TradeService {

    constructor() {
    }

    /**
     * 创建role记录
     * @param trade
     */
    add(trade) {
        return new Promise((resolved, rejected) => {
            if ( !trade ) {
                rejected(ERRCODE.SYSTEM_ERROR);
                return ;
            }

            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
                .then(connection => {

                    let sql = "INSERT INTO trade(tradeNo, openId, price, `desc`, resultCode, errCode, errCodeDes, created, updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
                    let params = [
                        trade.tradeNo, 
                        trade.openId,
                        trade.price,
                        trade.desc,
                        trade.resultCode,
                        trade.errCode,
                        trade.errCodeDes,
                        new Date().getTime(), 
                        new Date().getTime()];

                    // 执行SQL查询操作
                    return DBHelper.query(connection, sql, params)
                        .then(result => {
                            connection.release(); // 释放链接
                            console.log("add trade result: ", result);
                            resolved(result);
                        });
                })
                .catch(err => {
                    console.error("add trade err: ", err);
                    rejected(ERRCODE.SYSTEM_ERROR);
                    return ;
                });
        });
    }

    /**
     * 更新 trade 记录
     * @param trade
     */
    modify(trade) {
        return new Promise((resolved, rejected) => {
            if ( !role ) {
                rejected(ERRCODE.SYSTEM_ERROR);
                return ;
            }

            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
                .then(connection => {

                    let sql = "UPDATE trade SET resultCode=?, errCode=?, errCodeDes=?, updated=? WHERE orderId=?";
                    let params = [
                        trade.resultCode,
                        trade.errCode,
                        trade.errCodeDes,
                        new Date().getTime(),
                        trade.orderId];

                    // 执行SQL查询操作
                    return DBHelper.query(connection, sql, params)
                        .then(result => {
                            connection.release(); // 释放链接
                            console.log("update trade result: ", result);
                            resolved(result);
                        });
                })
                .catch(err => {
                    console.error("update trade err: ", err);
                    rejected(ERRCODE.SYSTEM_ERROR);
                    return ;
                });
        });
    }

}

// 导出RoleManager
export default TradeService;
