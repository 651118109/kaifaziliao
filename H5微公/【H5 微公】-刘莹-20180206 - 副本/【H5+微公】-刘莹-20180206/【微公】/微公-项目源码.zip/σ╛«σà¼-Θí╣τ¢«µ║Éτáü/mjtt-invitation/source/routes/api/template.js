
import express, {Router} from 'express';
import {ERRCODE} from '../../util/errcode';
import {ConstCode} from '../../util/const';
import CommonUtil from '../../util/common.util';
import TemplateMessage from '../../models/template.message';
import TemplateMessageService from '../../service/template.message.service';

let router = new Router();
let commonUtil = new CommonUtil();
let templateMessageService = new TemplateMessageService();

/**
 * 获取模版消息的分页数据
 */
router.get('/list', (req, res, next) => {

    let count = req.query.count || ConstCode.PAGE_DEFAULT_COUNT;
    let page = req.query.page || 1; // 当前页（默认从1开始）
    let searchContent = req.query.searchContent || ""; // 搜索内容信息

    // 返回数据包
    let resp = {
        code:ERRCODE.SUCCESS,
        data: {}
    };

    page = parseInt(page);
    Promise.all([
        templateMessageService.searchWithPaginator(page, count, searchContent),
        templateMessageService.getSizeWithContent(searchContent)
    ]).then(results => {
        resp.data = {
            items: results[0],
            paginator: commonUtil.genPaginator(page, results[1], count),
            search: {
                content: searchContent
            }
        };
        resp.data.paginator.curPage = page;
        console.log("template resp: ", resp);
        res.json(resp);
    }).catch(err => {
        console.error("err: ", err);
        resp.code = err;
        return res.json(resp);
    });
});

/**
 * 添加模版消息
 */
router.post('/add', (req, res, next) => {

    let name = req.body.name || "";
    let content = req.body.content || "";

    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    if ( !name || !content ) {
        console.error("wrong parameter. name: ", name, ", content: ", content);
        resp.code = ERRCODE.PARAMETER_ERROR;
        return res.jsonp(resp);
    }

    let template = new TemplateMessage();
    template.name = name;
    template.content = content;
    template.status = 0;
    template.created = new Date().getTime();
    template.updated = template.created;


    templateMessageService.add(template)
    .then(result => {
        console.log("add template result: ", result);
        return res.jsonp(resp);
    })
    .catch(err => {
        console.error("err: ", err);
        resp.code = ERRCODE.SYSTEM_ERROR;
        return res.jsonp(resp);
    });

});

/**
 * 编辑模版消息
 */
router.post('/edit', (req, res, next) => {
    
    let templateId = req.body.templateId || "";
    let name = req.body.name || "";
    let content = req.body.content || "";

    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    if ( !templateId || !name || !content ) {
        console.error("wrong parameter. templateId: ", templateId, " name: ", name, ", content: ", content);
        resp.code = ERRCODE.PARAMETER_ERROR;
        return res.jsonp(resp);
    }

    templateMessageService.get(templateId)
    .then(template => {
        template.name = name;
        template.content = content;
        return templateMessageService.modify(template);
    })
    .then(result => {
        console.log("update template result: ", result);
        return res.jsonp(resp);
    })
    .catch(err => {
        console.error("err: ", err);
        resp.code = ERRCODE.SYSTEM_ERROR;
        return res.jsonp(resp);
    });

});

/**
 * 删除模版消息
 */
router.post('/del', (req, res, next) => {
    
    let templateId = req.body.templateId || "";   
    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    templateMessageService.del(templateId)
    .then(result => {
        console.log("delete template result: ", result);
        return res.jsonp(resp);
    })
    .catch(err => {
        console.error("err: ", err);
        resp.code = ERRCODE.SYSTEM_ERROR;
        return res.jsonp(resp);
    });

});

module.exports = router;