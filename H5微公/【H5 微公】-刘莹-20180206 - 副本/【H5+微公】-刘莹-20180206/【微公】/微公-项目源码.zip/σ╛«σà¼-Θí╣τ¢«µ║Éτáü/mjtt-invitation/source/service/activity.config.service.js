
import ActivityConfig from '../models/activity.config';
import {ConstCode} from '../util/const';
import {ERRCODE} from '../util/errcode';
import DBHelper from '../db/mysql.connector';

/**
 * 处理配置信息
 */
class ActivityConfigSevice {

    /**
     * 获取配置信息
     * @param {*配置名称 } configName 
     */
    getConfig(configName) {
        return new Promise((resolved, rejected) => {

            return DBHelper.getConnection()
            .then(connection => {
                
                let sql = "SELECT * FROM activity_config WHERE configName = ? LIMIT 1";
                let params = [configName];
                return DBHelper.query(connection, sql, params).then(result => {
                    
                    if ( !result ) {
                        console.error("exec sql: ", sql, " with undefined result");
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }

                    if ( result.length <= 0 ) {
                        console.error("exec sql: ", sql, " with param: ", params, " has no result");
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }

                    let config = new ActivityConfig();
                    if ( !config.loadFrom(result[0]) ) {
                        console.log("load datas to config object failed");
                        connection.release();
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    connection.release();
                    resolved(config);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 修正配置信息
     * @param {*配置对象 } config 
     */
    modify(config) {
        return new Promise((resolved, rejected) => {

            if ( !config ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection()
            .then(connection => {

                let sql = "UPDATE activity_config SET banner=?, goodsIntroBanner=?, qrcodeBG=?, price=?, needFPCount=?, updated=? WHERE configName=? LIMIT 1";
                let params = [
                    config.banner,
                    config.goodsIntroBanner,
                    config.qrcodeBG,
                    config.price,
                    config.needFPCount,
                    new Date().getTime(),
                    config.configName
                ];

                console.log("exec sql: ", sql, " with params: ", params);

                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release();
                    console.log("result: ", result);
                    resolved(result);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

};

export default ActivityConfigSevice;