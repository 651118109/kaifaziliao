import Request from 'request';
import { resolve } from "path";

let HttpClient = () => {    
};

/**
 * 使用promise的方式处理http请求
 * based upon request
 * @author Allen.Wu
 */
HttpClient.prototype.get = (url) => {

    return new Promise((resolved, rejected) => {
        return Request(url, (err, resp, body) => {
            console.log("url: ", url, ", err: ", err, ", resp.statusCode: ", resp.statusCode, ", body: ", body);
            if ( !!err ) {
                console.log("request from url failed. url: ", url);
                rejected(err);
                return ;
            }
            if ( resp.statusCode != 200 ) {
                console.log("resp.statusCode is not correct. code: ", resp.statusCode);
                rejected(resp.statusCode);
                return ;  
            }
            resolved(body);
            return;
        });
    });
};

/**
 * POST请求
 * @param {*URL地址} url 
 * @param {*json格式参数} params 
 */
HttpClient.prototype.post = (url, params) => {

    return new Promise((resolved, rejected) => {
        return Request({
            uri: url,
            method: "POST",
            json: params
        }, (err, resp, body) => {
            console.log("url: ", url, ", err: ", err, ", resp.statusCode: ", resp.statusCode, ", body: ", body);
            if ( !!err ) {
                console.log("request from url failed. url: ", url);
                rejected(err);
                return ;
            }
            if ( resp.statusCode != 200 ) {
                console.log("resp.statusCode is not correct. code: ", resp.statusCode);
                rejected(resp.statusCode);
                return ;  
            }
            resolved(body);
            return;
        });
    });
}

// 传输xml
HttpClient.prototype.postXML = (url, data) => {

    return new Promise((resolved, rejected) => {
        return Request({
            uri: url,
            method: "POST",
            headers: {
                "Content-Type": "application/xml"
            },
            body: data
        }, (err, resp, content) => {
            console.log("url: ", url, ", err: ", err, ", content: ", content);
            if ( !!err ) {
                console.log("request from url failed. url: ", url);
                rejected(err);
                return ;
            }
            if ( resp.statusCode != 200 ) {
                console.log("resp.statusCode is not correct. code: ", resp.statusCode);
                rejected(resp.statusCode);
                return ;  
            }
            resolved(content);
            return;
        });
    });
}
 
 export default HttpClient;