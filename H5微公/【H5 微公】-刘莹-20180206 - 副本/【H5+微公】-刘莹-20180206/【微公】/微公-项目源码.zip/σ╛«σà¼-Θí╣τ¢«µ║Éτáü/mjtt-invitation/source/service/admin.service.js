/**
 * 负责Admin数据的操作接口
 * Created by allen on 2017/4/1.
 */

import Admin from '../models/admin';
import AdminRoleInfo from '../models/admin.role';
import {ConstCode} from '../util/const';
import {ERRCODE} from '../util/errcode';
import DBHelper from '../db/mysql.connector';

class AdminService {

    constructor() {
    }

    getById(adminId) {
        // 返回一个promise对象
        return new Promise((resolved, rejected) =>  {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
                .then(connection => {

                let sql = "SELECT * FROM Admin WHERE id = ? LIMIT 1";
                let params = [adminId];
                return DBHelper.query(connection, sql, params).then((result) => {
                    if (!result) {
                        console.error("exec sql:", sql, " with undefined result!");
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    if ( result.length <= 0 ) {
                        console.error("exec sql: ", sql, " with param: ", params, " has not result!");
                        connection.release();
                        rejected(ERRCODE.USER_NOT_EXISTS_ERROR);
                        return ;
                    }
                    let admin = new Admin();
                    if ( !admin.loadFrom(result[0]) ) {
                        console.log("load datas to admin object failed");
                        connection.release();
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    connection.release();
                    resolved(admin);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 根据用户名获取用户信息
     * @param username
     */
    getByUsername(username) {
        // 返回一个promise对象
        return new Promise((resolved, rejected) =>  {
            return DBHelper.getConnection().then((connection) => {

                let sql = "SELECT * FROM Admin WHERE username = ? LIMIT 1";
                return DBHelper.query(connection, sql, [username]).then((result) => {
                    if (!result) {
                        console.error("exec sql:", sql, " with undefined result!");
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    if ( result.length <= 0 ) {
                        console.error("exec sql: ", sql, " has not result!");
                        connection.release();
                        rejected(ERRCODE.USER_NOT_EXISTS_ERROR);
                        return ;
                    }
                    let admin = new Admin();
                    if ( !admin.loadFrom(result[0]) ) {
                        console.log("load datas to admin object failed");
                        connection.release();
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    connection.release();
                    resolved(admin);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 带搜索的分页检索信息
     * @param curPage
     * @param count
     * @param content (用户名、昵称、手机号码检索)
     */
    searchWithPaginator(curPage, count, content) {

        return new Promise((resolved, rejected) => {
            return DBHelper.getConnection().then(connection => {

                // 构建sql
                let sql = "SELECT admin.id as id, admin.username as username, admin.status as status, admin.created as created, admin.updated as updated, role.name as rolename FROM admin, role WHERE admin.roleId = role.id ";

                let params = [];
                if ( content ) {
                    sql += " AND admin.username like ? OR role.name like ?";
                    let condition = "%" + content + "%";
                    params = params.concat([], [condition, condition, condition, condition]);
                }
                sql += " ORDER BY id DESC LIMIT ? OFFSET ?";
                params = params.concat([], [count, (curPage - 1) * count]);

                // 执行查询
                return DBHelper.query(connection, sql, params).then(result => {
                    // 释放连接
                    connection.release();

                    let admins = [];
                    for ( let i=0; i<result.length; i++) {
                        let info = new AdminRoleInfo();
                        if ( !info.loadFrom(result[i]) ) {
                            console.error("load datas to admin role info object failed");
                            continue;
                        }
                        admins.push(info);
                    }
                    resolved(admins);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 根据筛选条件，获取记录总条数
     * @param content
     * @returns {Promise}
     */
    getSizeWithContent(content) {
        return new Promise((resolved, rejected) => {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND).then(connection => {

                // 构建sql
                let sql = "SELECT count(admin.id) as count FROM admin, role WHERE admin.roleId = role.id ";

                let params = [];
                if ( content ) {
                    sql += " AND admin.username like ? OR role.name like ?";
                    let condition = "%" + content + "%";
                    params = params.concat([], [condition, condition, condition, condition]);
                }

                // 执行查询
                return DBHelper.query(connection, sql, params).then(result => {
                    // 释放连接
                    connection.release();
                    console.log(result);
                    resolved(result[0]["count"]);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    add(admin) {
        return new Promise((resovled, rejected)=>{
            if ( !admin ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND).then(connection => {

                let sql = "INSERT INTO Admin (roleId, username, password, status, created, updated) VALUES (?, ?, ?, ?, ?, ?)";
                let params = [
                    admin.roleId,
                    admin.username,
                    admin.password,
                    admin.status,
                    admin.created,
                    admin.updated
                ];

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release();
                    console.log("last inserted admin id: ", result.insertId);
                    resovled(result);
                });

            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    modify(admin) {
        return new Promise((resovled, rejected)=>{
            if ( !admin ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND).then(connection => {

                let sql = "UPDATE Admin set username=?, roleId=?, status=?, updated=? WHERE id=? LIMIT 1";
                let params = [
                    admin.username,
                    admin.roleId,
                    admin.status,
                    new Date().getTime(),
                    admin.adminId
                ];

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release();
                    console.log("result: ", result);
                    resovled(result);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 修改密码
     * @param admin
     * @returns {Promise}
     */
    changePassword(admin) {
        return new Promise((resovled, rejected)=>{
            if ( !admin ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND).then(connection => {

                let sql = "UPDATE Admin set password=?, updated=? WHERE id=? LIMIT 1";
                let params = [
                    admin.password,
                    new Date().getTime(),
                    admin.adminId
                ];

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release();
                    console.log("result: ", result);
                    resovled(result);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 删除记录
     * @param adminId
     * @returns {Promise}
     */
    delById(adminId) {
        return new Promise((resolved, rejected) => {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
                .then( connection => {
                    let sql = "DELETE FROM Admin WHERE id = ?";
                    let params = [adminId];

                    return DBHelper.query(connection, sql, params)
                        .then(result => {
                            connection.release();
                            console.log("result: ", result);
                            resolved(result);
                        });
                }).catch( err => {
                    console.error(err);
                    rejected(ERRCODE.SYSTEM_ERROR);
                });
        });
    }
}

// 导出AdminManager
export default AdminService;
