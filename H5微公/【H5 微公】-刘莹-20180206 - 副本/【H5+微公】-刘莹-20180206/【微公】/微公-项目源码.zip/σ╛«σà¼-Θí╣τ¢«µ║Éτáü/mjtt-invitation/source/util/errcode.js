/**
 * Created by allen on 2017/4/4.
 */

let ERRCODE = {
    SUCCESS: 0,             // 成功

    PARAMETER_ERROR: 1001,             // 传入参数错误
    SYSTEM_ERROR: 1002,                // 系统未知错误

    USER_NOT_EXISTS_ERROR: 2001,       // 用户不存在
    PASSWORD_NOT_CORRECT_ERROR: 2002,  // 密码不正确
    USER_ALREADY_EXISTS_ERROR: 2003,   // 用户已存在
    USER_NOT_WAIT_VERIFIED_ERROR: 2004,// 用户未申请认证
    ROLE_ALREADY_EXISTS_ERROR: 2005,   // 角色已存在
    ROLE_NOT_EXISTS_ERROR: 2006,       // 角色不存在
};

module.exports.ERRCODE = ERRCODE;