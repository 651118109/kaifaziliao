/**
 * Created by allen on 2017/4/7.
 */
import {ConstCode} from '../util/const';

class Role {

    constructor() {
        this.roleId = 0;
        this.name = "";
        this.menuIds = "";
        this.status = ConstCode.VALID_RECORD;
        this.created = 0;
        this.updated = 0;
    }

    loadFrom(datas) {
        if (!datas) {
            return false;
        }

        this.roleId = datas["id"];
        this.name = datas["name"];
        this.menuIds = datas["menuIds"];
        this.status = datas["status"];
        this.created = datas["created"];
        this.updated = datas["updated"];
        return true;
    }

    toJson() {
        return {
            roleId: this.roleId,
            name: this.name,
            menuIds: this.menuIds,
            updated: this.updated
        };
    }

    toString() {
        return JSON.stringify(this.toJson());
    }

}

export default Role;