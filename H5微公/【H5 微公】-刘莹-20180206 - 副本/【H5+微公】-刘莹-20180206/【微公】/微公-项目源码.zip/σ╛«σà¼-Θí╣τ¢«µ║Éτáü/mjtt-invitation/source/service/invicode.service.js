
import Config from '../../config/meijing.json';
import {ERRCODE} from '../util/errcode';
import HttpClient from '../util/http.client';
import crypto from 'crypto';

let httpClient = new HttpClient();

/**
 * 从美景服务器中获取邀请码信息
 */
class InviCodeService {

    constructor(){        
    }

    /**
     * 生成签名
     * @param {*签名前内容} content 
     */
    makeSign(content) {
        console.log("content: ", content);
        content = new Buffer(content).toString('base64');
        console.log("content after base64: ", content);
        let md5 = crypto.createHash('md5')
        md5.update(content)
        return md5.digest('hex').toLowerCase()
    }

    /**
     * 好友力达到获取邀请码
     * @param {*微信用户的openId} openId 
     * @param {*需要的好友力} needFpCount 
     * @param {*当前好友力} fpCount 
     */
    generateCode(openId, needFpCount, fpCount) {
        return new Promise((resolved, rejected) => {

            let url = Config.domain + Config.generateCode;
            let current = new Date().getTime();
            let params = {
                "openId": openId,
                "needFpCount": needFpCount,
                "fpCount": fpCount,
                "timestamp": current,
                "sign": this.makeSign("openid|"+openId+"|needFPCount|"+needFpCount+"|fpCount|"+fpCount+"|"+current)
            };
            console.log("params: ", params);
            httpClient.post(url, params)
            .then(result => {
                console.log("result: ", result);
                if (result["code"] != 0) {
                    console.error("wrong result: ", result);
                    rejected(ERRCODE.SYSTEM_ERROR);
                    return ;
                }
                if ( result["data"] == null || result["data"]["inviCode"] == null ) {
                    console.error("wrong result: ", result);
                    rejected(ERRCODE.SYSTEM_ERROR);
                }
                // 返回xx码
                resolved(result["data"]["inviCode"]);
            })
            .catch(err => {
                console.log("err: ", err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 购买邀请码
     * @param {*交易流水号} transactionId 
     * @param {*微信用户号} openId 
     */
    buyCode(transactionId, openId) {
        return new Promise((resolved, rejected) => {
            
            let url = Config.domain + Config.buyCode;
            let current = new Date().getTime();
            let params = {
                "transactionId": transactionId,
                "openId": openId,
                "timestamp": current,
                "sign": this.makeSign("transactionId|"+transactionId+"|openid|"+openId+"|"+current)
            };
            httpClient.post(url, params)
            .then(result => {
                console.log("result: ", result);
                if (result["code"] != 0) {
                    console.error("wrong result: ", result);
                    rejected(ERRCODE.SYSTEM_ERROR);
                    return ;
                }
                if ( result["data"] == null || result["data"]["inviCode"] == null ) {
                    console.error("wrong result: ", result);
                    rejected(ERRCODE.SYSTEM_ERROR);
                }
                // 返回xx码
                resolved(result["data"]["inviCode"]);
            })
            .catch(err => {
                console.log("err: ", err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

}

export default InviCodeService;