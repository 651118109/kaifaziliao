import InvitationUtil from './invitation.util';

let invitationUtil = new InvitationUtil();

let replyMsg = (info, session) => {

	if (!info || !info.type || !info.content) {
		return false;
	}

	if (info.type == "text") {

		session.replyTextMessage(info.content);

		return true;

	} else if (info.type == "img") {

		session.replyMessage({
		    MsgType: 'image',
		    MediaId: info.content
  		});

  		return true;

	} else if (info.type == "news") {


		let newsArr = [];

		for (let i = info.news_info.list.length - 1; i >= 0; i--) {
			
			let news = {

				Title: info.news_info.list[i].title,
			    Description: info.news_info.list[i].digest,
			    PicUrl: info.news_info.list[i].cover_url,
			    Url: info.news_info.list[i].content_url

			};

			newsArr.push(news);

		}


		session.replyNewsMessage(newsArr);

  		return true;

	}

	return false;
}

//处理微信文本消息事件
module.exports.handleWeixinText = (session) => {

	console.log("Enter Text");

	let bReply = false;
	let setting = global.AutoReplySetting;

	if (setting.is_autoreply_open) {

		// 关键词自动回复
		let content = session.incomingMessage.Content;
		let infos = setting.keyword_autoreply_info.list;

		for (let infoIndex = infos.length - 1; infoIndex >= 0; infoIndex--) {

			let info = infos[infoIndex];
			let keyList = info.keyword_list_info;
			let replyList = info.reply_list_info;
			let bMatch = false;

			// 匹配关键词

			for (let keyIndex = keyList.length - 1; keyIndex >= 0; keyIndex--) {

				let key = keyList[keyIndex];
				
				if (key.type != "text") {
					continue;
				}

				if(key.match_mode === "contain" && key.content.indexOf(content) >= 0
					|| key.match_mode === "equal" && key.content === content) {

					bMatch = true;
					break;
				}
			}

			if (bMatch) {

				if(info.reply_mode === "reply_all") {
					for (let i = replyList.length - 1; i >= 0; i--) {
						if(replyMsg(replyList[i], session)) {
							bReply = true;
						}
					}
				} else if (info.reply_mode === "random_one") {

					let index = Math.round(Math.random() * (replyList.length - 1));

					if(replyMsg(replyList[index], session)) {
						bReply = true;
					}
				}
				
				break;
			}
		}


		// 消息自动回复
		if (!bReply) {

			if(replyMsg(setting.message_default_autoreply_info, session)) {
				bReply = true;
			}
		}

	}

	if (!bReply) {
		console.log("handleWeixinText unReply");
		return session.res.end();;
	}

}

//处理微信关注事件
module.exports.handleWeixinEventSubscribe = (session) => {

	console.log("Enter EventSubscribe");

	let setting = global.AutoReplySetting;
	
	if (setting.is_add_friend_reply_open) {

		if(!replyMsg(setting.add_friend_autoreply_info, session)) {
			 session.res.end();
		}
	} else {
		session.res.end();
	}

	
	let eventkey = session.incomingMessage.EventKey;
	
	// 关注带参数扫码
    if (eventkey === "qrscene_activity_invitation") {    //邀请卡活动
        invitationUtil.scanInvitation(session.incomingMessage.FromUserName);
    } else if (eventkey.startsWith("qrscene_sharer_")) { //分享邀请卡
        invitationUtil.scanShareInvitation(eventkey.substring(15), session.incomingMessage.FromUserName);
    } else if (eventkey) {
        console.log("subscribe unknow eventkey: ", eventkey);
    }

}

//处理微信扫码进入事件
module.exports.handleWeixinEventScan = (session) => {

	console.log("Enter EventScan");

	session.res.end();

	let eventkey = session.incomingMessage.EventKey;

	//继续后续逻辑
    if (eventkey === "activity_invitation") {
        invitationUtil.scanInvitation(session.incomingMessage.FromUserName);
    } else if (eventkey.startsWith("sharer_")) {
        invitationUtil. scanShareInvitation(eventkey.substring(7), session.incomingMessage.FromUserName);
    } else if (eventkey) {
        console.log("SCAN unknow eventkey: ", eventkey);
    }

}

//处理自定义菜单点击事件
module.exports.handleWeixinEventClick = (session) => {

	console.log("Enter EventClick");

	let eventkey = session.incomingMessage.EventKey;

	//继续后续逻辑
    if (eventkey.startsWith("text_")) {

    	let content = eventkey.substring(5);
        
        let info = {
        	"type": "text",
        	"content" : content
        };

        replyMsg(info, session);

    } else if (eventkey) {
    	
    	session.res.end();
        console.log("EventClick unknow eventkey: ", eventkey);
    }

}