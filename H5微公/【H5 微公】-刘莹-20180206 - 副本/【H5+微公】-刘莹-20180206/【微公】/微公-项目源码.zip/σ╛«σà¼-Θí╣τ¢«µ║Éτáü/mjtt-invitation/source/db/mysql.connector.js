/**
 * Created by allen on 2017/4/1.
 */
import mysql from 'mysql';
import {ConstCode} from '../util/const';
import dbconfig from '../../config/database.json';

// 创建数据库连接池
let mjttPool = mysql.createPool(dbconfig.mjtt);

/**
 * 从连接池中获取连接
 * Tips: 需要调用者进行conn.release。否则会造成雪崩效应
 * @returns {Promise}
 */
exports.getConnection = () => {
    return new Promise((resovled, rejected) => {
        mjttPool.getConnection((err, conn) => {
            // 出错了，rejected
            if ( !!err ) {
                console.error("get mjtt connectin err: ", err);
                rejected(err);
                return ;
            }
            // 返回连接
            resovled(conn);
        });            
    });
};

/**
 * 使用connection完成数据库查询操作
 * @param conn
 * @param sql
 * @param params
 */
exports.query = (conn, sql, params) => {
    return new Promise((resolved, rejected) => {

        if ( !conn || !sql ) {
            console.error("no connection or no sql. conn: ", conn, ", sql: ", sql);
            rejected("parameter error");
            return ;
        }

        // 真正执行查询的地方
        conn.query(sql, params, (err, result) => {
            if ( !!err ) {
                console.error("exec sql: ", sql, " with param: ", params, " failed. err: ", err);
                rejected(err);
                return ;
            }
            resolved(result);
        });
    });
};