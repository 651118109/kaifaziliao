/**
 * Created by allen on 2017/4/7.
 */

import Role from '../models/role';
import {ConstCode} from '../util/const';
import {ERRCODE} from '../util/errcode';
import DBHelper from '../db/mysql.connector';

class RoleService {

    constructor() {
    }

    /**
     * 根据ID获取记录信息
     * @param roleId
     */
    getById(roleId) {
        return new Promise((resolved, rejected) =>  {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND).then((connection) => {

                let sql = "SELECT * FROM role WHERE id = ? LIMIT 1";
                return DBHelper.query(connection, sql, [roleId]).then((result) => {
                    console.log("result: ", result);
                    if (!result) {
                        console.error("exec sql:", sql, " with undefined result!");
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    if ( result.length <= 0 ) {
                        console.error("exec sql: ", sql, " has not result!");
                        connection.release();
                        rejected(ERRCODE.ROLE_NOT_EXISTS_ERROR);
                        return ;
                    }
                    let role = new Role();
                    if ( !role.loadFrom(result[0]) ) {
                        console.log("load datas to role object failed");
                        connection.release();
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    connection.release();
                    resolved(role);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 根据角色名称获取角色
     * @param name
     * @returns {Promise}
     */
    getByName(name) {
        // 返回一个promise对象
        return new Promise((resolved, rejected) =>  {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND).then((connection) => {

                let sql = "SELECT * FROM role WHERE name = ? LIMIT 1";
                return DBHelper.query(connection, sql, [name]).then((result) => {
                    if (!result) {
                        console.error("exec sql:", sql, " with undefined result!");
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    if ( result.length <= 0 ) {
                        console.error("exec sql: ", sql, " has not result!");
                        connection.release();
                        rejected(ERRCODE.ROLE_NOT_EXISTS_ERROR);
                        return ;
                    }
                    let role = new Role();
                    if ( !role.loadFrom(result[0]) ) {
                        console.log("load datas to role object failed");
                        connection.release();
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    connection.release();
                    resolved(role);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    // 获取所有角色信息
    getAll() {
        // 返回一个promise对象
        return new Promise((resolved, rejected) =>  {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND).then((connection) => {

                let sql = "SELECT * FROM role";
                return DBHelper.query(connection, sql, []).then((result) => {
                    connection.release();
                    if (!result) {
                        console.error("exec sql:", sql, " with undefined result!");
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    let datas = [];
                    for (let i=0; i<result.length; i++) {
                        let role = new Role();
                        if ( !role.loadFrom(result[i]) ) {
                            continue;
                        }
                        datas.push(role);
                    }
                    resolved(datas);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 搜索角色名字
     * @param curPage
     * @param count
     * @param content
     */
    searchWithPaginator(curPage, count, content) {
        return new Promise((resolved, rejected) => {
           return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
               .then(connection => {

                   let sql = "SELECT * FROM role";
                   let params = [];

                   if ( content ) {
                       let condition = '%' + content + '%';
                       sql += " WHERE role.name like ?";
                       params.push(condition);
                   }

                   sql += " ORDER BY id DESC LIMIT ? OFFSET ?";
                   params = params.concat([], [count, (curPage - 1) * count]);

                   // 执行查询操作
                   return DBHelper.query(connection, sql, params).then(result => {
                       connection.release(); // 释放链接
                       console.log("results: ", result);
                       let datas = [];
                       for (let i=0; i<result.length; i++) {
                           let info = new Role();
                           if ( !info.loadFrom(result[i]) ) {
                               continue;
                           }
                           datas.push(info);
                       }
                       resolved(datas);
                   });
               })
               .catch(err => {
                   console.error(err);
                   rejected(ERRCODE.SYSTEM_ERROR);
               });
        });
    }

    /**
     * 根据查询结果获取结果数量
     * @param content
     */
    getSizeWithContent(content) {
        return new Promise((resolved, rejected) => {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
                .then(connection => {

                    let sql = "SELECT count(id) as count FROM role";
                    let params = [];

                    if ( content ) {
                        let condition = '%' + content + '%';
                        sql += " WHERE role.name like ?";
                        params.push(condition);
                    }

                    return DBHelper.query(connection, sql, params).then(result => {
                        connection.release(); // 释放链接
                        console.log(result);
                        resolved(result[0]["count"]);

                    });
                })
                .catch(err => {
                    console.error(err);
                    rejected(ERRCODE.SYSTEM_ERROR);
                });
        });
    }

    /**
     * 创建role记录
     * @param role
     */
    add(role) {
        return new Promise((resolved, rejected) => {
            if ( !role ) {
                rejected(ERRCODE.SYSTEM_ERROR);
                return ;
            }

            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
                .then(connection => {

                    let sql = "INSERT INTO role(name, menuIds, status, created, updated) VALUES (?, ?, ?, ?, ?);";
                    let params = [role.name, role.menuIds, ConstCode.VALID_RECORD, new Date().getTime(), new Date().getTime()];

                    // 执行SQL查询操作
                    return DBHelper.query(connection, sql, params)
                        .then(result => {
                            connection.release(); // 释放链接
                            console.log("add role result: ", result);
                            resolved(result);
                        });
                })
                .catch(err => {
                    console.error("add role err: ", err);
                    rejected(ERRCODE.SYSTEM_ERROR);
                    return ;
                });
        });
    }

    /**
     * 更新 role 记录
     * @param role
     */
    modify(role) {
        return new Promise((resolved, rejected) => {
            if ( !role ) {
                rejected(ERRCODE.SYSTEM_ERROR);
                return ;
            }

            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
                .then(connection => {

                    let sql = "UPDATE role SET name=?, menuIds=?, updated=? WHERE id=?";
                    let params = [
                        role.name,
                        role.menuIds,
                        new Date().getTime(),
                        role.roleId];

                    // 执行SQL查询操作
                    return DBHelper.query(connection, sql, params)
                        .then(result => {
                            connection.release(); // 释放链接
                            console.log("update role result: ", result);
                            resolved(result);
                        });
                })
                .catch(err => {
                    console.error("update role err: ", err);
                    rejected(ERRCODE.SYSTEM_ERROR);
                    return ;
                });
        });
    }

}

// 导出RoleManager
export default RoleService;
