
class Follow {

    /**
     * 初始化字段内容
     */
    constructor() {
        this.followId = 0;
        this.userOpenId = ""; // 用户openId
        this.friOpenId = "";  // 好友openId
        this.created = 0;
        this.updated = 0;
    }

    /**
     * 从数据库返回的结果集中加载数据
     * @param datas 字典类型（数据库的数据）
     */
    loadFrom(datas) {
        console.log("follow datas: ", datas);
        this.followId = datas["followId"];
        this.userOpenId = datas["userOpenId"];
        this.friOpenId = datas["friOpenId"];
        this.created = datas["created"];
        this.updated = datas["updated"];
        return true;
    }

    /**
     * 返回一个json数据
     */
    toJson() {
        return {
            "followId": this.followId,
            "userOpenId": this.userOpenId,
            "friOpenId": this.friOpenId,
            "updated": this.updated
        };
    }

    /**
     * 返回一个stringify的json格式数据
     */
    toString() {
        return JSON.stringify(this.toJson());
    }

}

// 导出WxUser
export default Follow;