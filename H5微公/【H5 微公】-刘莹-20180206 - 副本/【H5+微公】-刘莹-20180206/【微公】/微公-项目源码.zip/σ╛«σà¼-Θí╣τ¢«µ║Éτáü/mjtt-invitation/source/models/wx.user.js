
import {ConstCode} from '../util/const';

class WxUser {

    /**
     * 初始化字段内容
     */
    constructor() {
        this.openId = "";
        this.inviteCode = "";
        this.status = ConstCode.ACTIVITY_NOT_APPLY;
        this.created = 0;
        this.updated = 0;
    }

    /**
     * 从数据库返回的结果集中加载数据
     * @param datas 字典类型（数据库的数据）
     */
    loadFrom(datas) {
        console.log("admin datas: ", datas);
        this.openId = datas["openId"];
        this.inviteCode = datas["inviteCode"];
        this.status = datas["status"];
        this.created = datas["created"];
        this.updated = datas["updated"];
        return true;
    }

    /**
     * 返回一个json数据
     */
    toJson() {
        return {
            "openId": this.openId,
            "inviteCode": this.inviteCode,
            "status": this.status,
            "updated": this.updated
        };
    }

    /**
     * 返回一个stringify的json格式数据
     */
    toString() {
        return JSON.stringify(this.toJson());
    }

}

// 导出WxUser
export default WxUser;