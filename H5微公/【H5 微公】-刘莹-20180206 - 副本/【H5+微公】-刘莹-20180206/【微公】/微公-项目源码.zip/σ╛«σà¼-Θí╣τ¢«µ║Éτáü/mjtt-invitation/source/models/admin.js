/**
 * Created by allen on 2017/4/1.
 * 对应数据库的backend.Admin表结构
 */
import {ConstCode} from '../util/const';
import {Codec} from '../util/codec';

let codec = new Codec();

class Admin {

    /**
     * 初始化字段内容
     */
    constructor() {
        this.adminId = 0;
        this.roleId = 0;
        this.username = "";
        this.password = "";
        this.status = ConstCode.NORMAL_ADMIN_STATUS;
        this.created = 0;
        this.updated = 0;
    }

    /**
     * 从数据库返回的结果集中加载数据
     * @param datas 字典类型（数据库的数据）
     */
    loadFrom(datas) {
        console.log("admin datas: ", datas);
        this.adminId = datas["id"];
        this.roleId = datas["roleId"];
        this.username = datas["username"];
        this.password = datas["password"];
        this.status = datas["status"];
        this.created = datas["created"];
        this.updated = datas["updated"];
        return true;
    }

    /**
     * 设置password，加密方式由内部决定
     * @param password
     */
    setPassword(password) {
        this.password = codec.md5(password);
    }


    /**
     * 检测密码是否匹配
     * @param password
     * @returns {boolean}
     */
    checkPassword(password) {
        let candidate = codec.md5(password);
        if ( this.password !== candidate ) {
            console.error("password not match. candidate passwd: ", candidate);
            return false;
        }
        return true;
    }

    /**
     * 返回一个json数据
     */
    toJson() {
        return {
            "adminId": this.adminId,
            "roleId": this.roleId,
            "username": this.username,
            "status": this.status,
            "updated": this.updated
        };
    }

    /**
     * 返回一个stringify的json格式数据
     */
    toString() {
        return JSON.stringify(this.toJson());
    }

}

// 导出Admin
export default Admin;
