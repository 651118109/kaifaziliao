/**
 * Created by allen on 2017/4/4.
 * 编解码的接口
 */

import crypto from 'crypto';

let Codec = () => {
};

/**
 * 获取md5值
 * @param content (返回小写字母)
 */
Codec.prototype.md5 = (content) => {
    let md5sum = crypto.createHash('md5');
    md5sum.update(content);
    return md5sum.digest('hex').toLowerCase();
};

module.exports.Codec = Codec;