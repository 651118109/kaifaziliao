import Config from '../../config/config.json';
import WxUser from '../models/wx.user';
import WxUserService from '../service/wx.user.service';
import HttpClient from './http.client';
import request from 'request';
import {ERRCODE} from './errcode';
import {ConstCode} from './const';
import Follow from '../models/follow';
import FollowService from '../service/follow.service';
import InviCodeService from '../service/invicode.service';
import gm from 'gm';
import fs from 'fs';


let wxUserService = new WxUserService();
let followService = new FollowService();
let inviCodeService = new InviCodeService();
let httpClient = new HttpClient();

class InvitationUtil {

    constructor() {        
    }

    /**
	 * 下载文件
	 */
	downloadFile(uri, filename){
	    return new Promise((resolved, rejected) => {

	        if ( !uri ) {
	            console.error("wrong uri for downloadFile");
	            rejected(ERRCODE.PARAMETER_ERROR);
	            return ;
	        }

	        if ( !filename ) {
	            console.log("wrong filename: ", filename);
	            rejected(ERRCODE.PARAMETER_ERROR);
	            return ;
	        }

	        let stream = fs.createWriteStream(filename);
	        request(uri).pipe(stream)
	        .on('close', () => {
	            console.log("download uri:", uri, " to filename: ", filename + " success!!");
	            resolved(ERRCODE.SUCCESS);
	        });
	    });
	}

    Enter(openId) {

    	console.log("Enter invitation 主流程, openId :", openId);

	    //进入活动流程
	    let send_custom_url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + global.access_token;
	    let back_image_url;
	    let qrcode_url;
	    let bg_file;
	    let qrcode_file;
	    let output_file;
	    // 向美景后台请求用户活动进度（若未开始活动，则开始活动）
		// 发送内容 openid
		// 收到内容 活动进度：申请中（好友总数，剩余好友力，邀请卡价格），已申请（邀请码）。
		// 申请中，则公众号中发活动模板消息
	    // 已申请，则公众号中提示已获得邀请码，发送邀请码。
	    let bEnd = false;
	    let inviteCode;
	    wxUserService.get(openId)
	    .then(user => {

	        console.log("get user:", user);

	        // 改变用户状态
	        if (user.status == ConstCode.ACTIVITY_NOT_APPLY) {
	            user.status = ConstCode.ACTIVITY_APPLYING;
	        } else if (user.status == ConstCode.ACTIVITY_END_APPLY) {
	            bEnd = true;
	            inviteCode = user.inviteCode;
	        }

	        return wxUserService.modify(user);
	    })
	    .then(result => {

	        console.log("modify user result: ", result);

	        if (!bEnd) {

	        	let content = global.template.intro;

	        	content = content.replace("{{total}}",global.activity.needFPCount);
	        	content = content.replace("{{price}}",global.activity.price);
	        	content = content.replace("{{url}}", "http://" + Config.domain + "/purchaseAuth");

	            // 发送活动介绍模板 
	            let param = {
	                "touser": openId,
		            "msgtype":"text",
		            "text":
		            {
		                 "content": content
		            }
	            }

	            console.log("send template intro: ", param);

	            return httpClient.post(send_custom_url, param); 

	        } else {

	        	// 已结束
	        	let content = global.template.achieve;
		        
		        let param = {
		            "touser": openId,
		            "msgtype":"text",
		            "text":
		            {
		                 "content": content
		            }
		        }

		        console.log("send template achieve: ", param);

		        return httpClient.post(send_custom_url, param);               
	        }

	    })
	    // 发送模板 返回
	    .then( content => {

	        console.log("send 模板 resp:", content);

	        if ( content.errcode != 0 || content.errmsg != "ok") {
	            console.log("errcode:", content.errcode, ", errmsg:", content.errmsg);

				return new Promise((resolved, rejected) => {
	                rejected(null);
	            });
	        }

	        if (!bEnd) {

	            console.log("请求二维码图片");
	            // 请求二维码图片
	            let req_qrcode_url = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=" + global.access_token;
	            let scene_str = "sharer_" + openId;
	            let param = {
	                "expire_seconds": 604800, 
	                "action_name": "QR_STR_SCENE", 
	                "action_info": {
	                    "scene": {
	                        "scene_str": scene_str
	                    }
	                }
	            }

	            return httpClient.post(req_qrcode_url, param);

	        } /*else {
	            res.json({                  
	                code: 200,
	                result: {
	                    message: '发送成功',
	                    msg: ''
	                }
	            });
	            return;
	        }*/
	    })
	    .then( content => {

	        console.log("请求二维码图片resp:", content);

	        if ( content.ticket == "") {
	            console.log("request image error: ", content);
	            return ;
	        }
	        
	        
	        back_image_url = global.activity.qrcodeBG;
	        qrcode_url = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=" + encodeURI(content.ticket);
	        bg_file = __dirname + "/../../public/download/bg.png";
	        qrcode_file = __dirname + "/../../public/download/qrcode.png";

	        return Promise.all([
	            this.downloadFile(back_image_url, bg_file),
	            this.downloadFile(qrcode_url, qrcode_file)
	        ]);        
	    })
	    .then(result => {
	        console.log("download file result: ", result);

	        // 将以上两张图片合成
	        output_file = __dirname + "/../../public/generator/invitationcard_" + openId + ".png";
	        let new_qrcode_file = __dirname + "/../../public/download/new_qrcode_" + openId + ".png";
	        let new_bg_file = __dirname + "/../../public/download/new_bg.png";
	        return new Promise((resolved, rejected) => {

	            gm(bg_file)
	            .resize('750', '1334', '!')
	            .autoOrient()  
	            .write(new_bg_file, (err) => { 

	                if (!err) {

	                    gm(qrcode_file)
	                    .resize('220', '220', '!')
	                    .autoOrient()  
	                    .write(new_qrcode_file, (errqrcode) => { 

	                        if (!errqrcode) {

	                            /*

	                            gm()
	                            .in('-page', '+0+0')
	                            .in(new_bg_file)
	                            .in('-page', '+38+1090')
	                            .in(new_qrcode_file)
	                            .mosaic()
	                            .write( output_file, (errmosaic) => {
	                                console.log('gm result: ', errmosaic)
	                                if (!errmosaic) {
	                                    resolved(ERRCODE.SUCCESS);
	                                } else {                        
	                                    rejected(errmosaic);
	                                }
	                            });
	                            */

	                            gm()
	                            .command("composite") 
	                            .in("-geometry", "+38+24")
	                            .in("-gravity", "SouthWest")
	                            .in(new_qrcode_file)
	                            .in(new_bg_file)
	                            .write(output_file, function (err) {
	                              if (!err) 
	                                resolved(ERRCODE.SUCCESS);
	                              else
	                                rejected(err);
	                            })

	                        }  else {
	                            rejected(errqrcode);
	                        }
	                    });

	                }  else {
	                    rejected(err);
	                }
	            });
	        });
	        
	    })
	    .then(result => {
	        console.log("composite pic result: ", result);  


	        return new Promise((resolved, rejected) => {

	            let url = "https://api.weixin.qq.com/cgi-bin/media/upload?access_token=" + global.access_token + "&type=image";
	            let formData = {
	                media : fs.createReadStream(output_file)
	            };

	            request.post({url:url, formData: formData}, (err, httpResponse, body) => {

	                if (err) {
	                    rejected(err);
	                    return ;
	                }

	                let data;
	                try {
	                    data = JSON.parse(body);
	                } catch(error) {
	                    console.log("wrong data from weixin upload. err:", error);
	                    rejected(error);
	                    return ;
	                }

	                let errcode = data.errcode || 0;
	                if (errcode != 0) {
	                    rejected(data);
	                    return;
	                }
	                resolved(data);
	            });
	        });
	    })
	    .then(body => {

	        console.log('Upload successful!  Server responded with:', body);

	        let send_image_data = {
	            "touser": openId,
	            "msgtype":"image",
	            "image": {
	                "media_id":body.media_id
	            }

	            //"msgtype":"text",
	            //"text":
	            //{
	            //     "content":" Hello World\n http://" + Config.domain + "/purchase"
	            //}
	        }
	        console.log("send_image_data", send_image_data);
	        // 发送二维码到公众号
	        return httpClient.post(send_custom_url, send_image_data);

	    })
	    .then( content => {
	        console.log("content: ", content);
	    })
	    .catch(err => {
	        console.error("err: ", err);
	    });
    }

    /**
	 * 扫描邀请卡活动二维码 
	 */
	scanInvitation(user_openid){


		let url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + global.access_token;
	    let data = {
	        "touser":user_openid,
	        "msgtype":"news",
	        "news":{
	            "articles": [{
	                "title": "幸运用户",
	                "description": "0元申请邀请码",
	                "url": "http://" + Config.domain + "/activityAuth",
	                "picurl": global.activity.banner
	            }]
	        }
	    }


		wxUserService.get(user_openid)
	    .then(user => {

	        console.log("get user => ", user);

	        // 用户不存在，添加用户
	        if ( user == null ) {

	            let current = new Date().getTime();
	            let wxUser = new WxUser();
	            wxUser.openId = user_openid;
	            wxUser.created = current;
	            wxUser.updated = current;
	            
	            console.log("add user : ", wxUser);                
	            wxUserService.add(wxUser)
	             .then(result => {

	                console.log("result for add user: ", result);

	                //未申请活动发送活动页面
				    return httpClient.post(url, data);

	            });

	        } else {

	            if (user.status != ConstCode.ACTIVITY_NOT_APPLY) {
	                
	                //已申请活动则进入邀请卡申请
	                this.Enter(user_openid);

	            } else {

	            	//未申请活动发送活动页面
	                return httpClient.post(url, data);
	            }

	        }
	    })
	    .then( content => {
	        console.log("content: ", content);
	    })
	    .catch(err => {
			console.error("err: ", err);
	    });

	}

	/**
	 * 扫描分享邀请卡二维码 
	 */
	scanShareInvitation(user_openid, friend_openid){

	    if (user_openid == friend_openid) {
	        
	        console.log("user_openid equal friend_openid, return");
	        return;
	    }

	    let bEnd = false;
	    let followCount = 0;
	    let user;
	    let inviteCode;
	    let userNickname ="";
	    let friendNickname = "";
	    let message_url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + global.access_token;
	    Promise.all([
	        followService.getCount(user_openid),
	        wxUserService.get(user_openid)
	    ])
	    .then(results => {

	        console.log("get followCount & user_openid :", results);

	        followCount = results[0];
	        user = results[1];

	        if ( user.status == ConstCode.ACTIVITY_END_APPLY ) { //TODO: 已经有了邀请码不处理

	             bEnd = true;
	             return;
	        }

	        let follow = new Follow();
	        let current = new Date().getTime();
	        follow.userOpenId = user_openid;
	        follow.friOpenId = friend_openid;
	        follow.created = current;
	        follow.updated = current;
	        return followService.add(follow);

	    })
	    .then( result => {

	        console.log("add follow result: ", result);

	        if(!bEnd) 
	            followCount ++;

	        let params = {
	           "user_list": [{
	                   "openid": user_openid, 
	                   "lang": "zh_CN"
	               }, {
	                   "openid": friend_openid, 
	                   "lang": "zh_CN"
	               }
	           ]
	        };
	        let url = "https://api.weixin.qq.com/cgi-bin/user/info/batchget?access_token=" + global.access_token;
	        return httpClient.post(url, params);

	        
	    })
	    .then( userInfoContent => { // 从微信获取用户信息

	        for(let i = 0; i < userInfoContent.user_info_list.length; i++) {
	            if( userInfoContent.user_info_list[i].openid === user_openid ) {
	                userNickname = userInfoContent.user_info_list[i].nickname;
	            } else if (userInfoContent.user_info_list[i].openid === friend_openid) {
	                friendNickname = userInfoContent.user_info_list[i].nickname;
	            }
	        }
	        console.log("user_nickname:", userNickname, ", friend_nickname: ", friendNickname);


	        let content = global.template.followHelp;

	        content = content.replace("{{friendname}}",userNickname);

	        let param = {
	            "touser": friend_openid,
	            "msgtype":"text",
	            "text":
	            {
	                 "content": content
	            }
	        }

	        // 发送消息给friend
	        return httpClient.post(message_url, param);
	    })
	    .then( results => {

	        console.log("send template message result: ", results);

	        if (bEnd) {
	            //已获得邀请码，不再提示
	            return new Promise((resolved, rejected) => {
	                rejected(null);
	            });
	        }

	        let content = global.template.getHelp;
	        let number = global.activity.needFPCount - followCount;
	        if ( followCount >= global.activity.needFPCount ) {
	            //完成任务
	            content = global.template.getHelpComplete;
	            number = followCount;
	        } 

	        content = content.replace("{{friendname}}",friendNickname);
	        content = content.replace("{{number}}",number);
	        content = content.replace("{{price}}",global.activity.price);

	        let param = {
	            "touser": user_openid,
	            "msgtype":"text",
	            "text":
	            {
	                 "content": content
	            }
	        }

	        //发给user
	        return httpClient.post(message_url, param);
	    })
	    .then( results => {

	        console.log("send template message result: ", results);

	        if ( followCount < global.activity.needFPCount ) {
	            console.log("还未完成任务");
	            return new Promise((resolved, rejected) => {
	                rejected(null);
	            });
	        }
	        // 从美景后台中获取
	        return inviCodeService.generateCode(user_openid, global.activity.needFPCount, followCount);
	    })
	    .then(invitcode => {
	    	// 完成任务，给他一个邀请码。
	        console.log("invitcode: ", invitcode);
	        user.inviteCode = invitcode;
	        user.status = ConstCode.ACTIVITY_END_APPLY;
	        return wxUserService.modify(user);
	    })
	    .then(result => {
	                
	        console.log("result for modify user: ", result);

	        let param = {
	            "touser": user_openid,
	            "msgtype":"text",
	            "text":
	            {
	                 "content": user.inviteCode
	            }
	        }

	        return httpClient.post(message_url, param);

	    })
	    .then(result => {
	                
	        console.log("result for send code: ", result);


	        let content = global.template.getCode;
	        
	        let param = {
	            "touser": user_openid,
	            "msgtype":"text",
	            "text":
	            {
	                 "content": content
	            }
	        }

	        return httpClient.post(message_url, param);

	    })
	    .then( result => {
	        console.log("send get code template message result: ", result);
	    })
	    .catch(err => {

	        console.error("scanShareInvitation error: ", err);
	    });
	}
}

export default InvitationUtil;