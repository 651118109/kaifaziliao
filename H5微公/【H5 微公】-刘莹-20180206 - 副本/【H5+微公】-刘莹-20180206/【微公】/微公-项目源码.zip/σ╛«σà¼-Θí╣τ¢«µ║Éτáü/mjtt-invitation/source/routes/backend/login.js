import express, {Router} from 'express';

let router = new Router();

/**
 * 跳转到backend/login.ejs
 */
router.get('/', (req, res, next) => {
    res.render('backend/login.ejs', {});
});

module.exports = router;