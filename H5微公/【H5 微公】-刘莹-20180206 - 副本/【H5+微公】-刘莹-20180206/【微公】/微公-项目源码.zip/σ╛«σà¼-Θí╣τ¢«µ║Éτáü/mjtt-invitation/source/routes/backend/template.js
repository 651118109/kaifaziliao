
import express, {Router} from 'express';
import TemplateMessageService from '../../service/template.message.service';

let router = new Router();
let templateMessageService = new TemplateMessageService();

// 跳转到模版消息显示页面
router.get('/list', (req, res, next) => {
    res.render('backend/activity/template.list.ejs');
});

// 跳转到添加模版消息页面
router.get('/add', (req, res, next) => {
    res.render('backend/activity/template.add.ejs');
});

// 跳转到角色编辑页面
router.get('/edit', (req, res, next) => {
    let templateId = req.query.templateId || "";

    //TODO: 获取template消息并渲染编辑页面
    templateMessageService.get(templateId)
    .then( template => {
        res.render('backend/activity/template.edit.ejs', {
            "template": template
        }); 
    })
    .catch(err => {
        console.error("get template by id failed: ", err);
        let error = new Error(err);
        next(error);
    });
});

module.exports = router;