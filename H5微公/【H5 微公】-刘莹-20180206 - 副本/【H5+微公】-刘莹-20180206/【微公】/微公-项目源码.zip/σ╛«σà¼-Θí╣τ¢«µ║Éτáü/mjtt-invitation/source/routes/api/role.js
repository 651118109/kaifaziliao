import express, {Router} from 'express';
import {ERRCODE} from '../../util/errcode';
import {ConstCode} from '../../util/const';
import RoleService from '../../service/role.service';
import MenuService from '../../service/menu.service';
import CommonUtil from '../../util/common.util';

import Role from '../../models/role';

let router = new Router();
let roleService = new RoleService();
let menuService = new MenuService();
let commonUtil = new CommonUtil();

/**
 * 获取权限列表信息
 */
router.get('/list', (req, res, next) => {

    let count = req.query.count || ConstCode.PAGE_DEFAULT_COUNT;
    let page = req.query.page || 1; // 当前页（默认从1开始）
    let searchContent = req.query.searchContent || ""; // 搜索内容信息

    // 返回数据包
    let resp = {
        code:ERRCODE.SUCCESS,
        data: {}
    };

    page = parseInt(page);
    Promise.all([
        roleService.searchWithPaginator(page, count, searchContent),
        roleService.getSizeWithContent(searchContent)
    ]).then(results => {
        resp.data = {
            items: results[0],
            paginator: commonUtil.genPaginator(page, results[1], count),
            search: {
                content: searchContent
            }
        };
        resp.data.paginator.curPage = page;
        console.log("role resp: ", resp);
        res.json(resp);
    }).catch(err => {
        console.error("err: ", err);
        resp.code = err;
        return res.json(resp);
    });

});

/**
 * 添加角色
 */
router.post('/add', (req, res, next) => {

    let name = req.body.name || "";
    let ids = req.body.ids || "";

    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    if ( !name || !ids ) {
        console.error("wrong parameter. name: ", name, ", ids: ", ids);
        resp.code = ERRCODE.PARAMETER_ERROR;
        return res.jsonp(resp);
    }

    // 先根据名字查看是否存在role
    roleService.getByName(name)
    .then(role => {
        console.log("already exists role: ", role);
        resp.code = ERRCODE.ROLE_ALREADY_EXISTS_ERROR;
        return res.jsonp(resp);
    })
    .catch(err => {

        // 如果不存在则添加角色
        if ( err === ERRCODE.ROLE_NOT_EXISTS_ERROR ) {
            let role = new Role();
            role.name = name;
            role.menuIds = ids;

            roleService.add(role)
            .then(result => {
                console.log("add role result: ", result);
                res.jsonp(resp);
            })
            .catch(err => {
                console.error("err: ", err);
                resp.code = err;
                return res.jsonp(resp);
            });
            return;
        }

        console.error("err: ", err);
        resp.code = err;
        return res.jsonp(resp);
    });

});

/**
 * 编辑角色
 */
router.post('/edit', (req, res, next) => {

    let roleId = req.body.roleId || 0;
    let name = req.body.name || "";
    let ids = req.body.ids || "";

    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    if ( !name || !ids ) {
        console.error("wrong parameter. name: ", name, ", ids: ", ids);
        resp.code = ERRCODE.PARAMETER_ERROR;
        return res.jsonp(resp);
    }

    // 选获取role对象
    roleService.getById(roleId)
    .then(role => {
        console.log("role: ", role);
        role.name = name;
        role.menuIds = ids;
        return roleService.modify(role);
    })
    .then(result => {
        console.log("update role result: ", result);
        res.jsonp(resp);
    })
    .catch(err => {
        console.error("err: ", err);
        resp.code = err;
        return res.jsonp(resp);
    });

});

/**
 * 获取所有角色信息
 */
router.get('/all', (req, res, next) => {

    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    // 获取所有角色信息
    roleService.getAll()
    .then(roles => {
        resp.data.roles = roles;
        return res.jsonp(resp);
    })
    .catch(err => {
        console.error("err: ", err);
        resp.code = err;
        return res.jsonp(resp);
    });

});

module.exports = router;