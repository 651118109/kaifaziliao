/**
 * Created by allen on 2017/4/7.
 */
import {ConstCode} from '../util/const';

class Menu {

    constructor() {
        this.menuId = 0;
        this.name = "";
        this.rootId = 0;
        this.parentId = 0;
        this.status = ConstCode.VALID_RECORD;
        this.created = 0;
        this.updated = 0;
    }

    loadFrom(datas) {
        if (!datas) {
            return false;
        }

        this.menuId = datas["id"];
        this.name = datas["name"];
        this.rootId = datas["rootId"];
        this.parentId = datas["parentId"];
        this.status = datas["status"];
        this.created = datas["created"];
        this.updated = datas["updated"];
        return true;
    }

    toJson() {
        return {
            menuId: this.menuId,
            name: this.name,
            rootId: this.rootId,
            parentId: this.parentId,
            updated: this.updated
        };
    }

    toString() {
        return JSON.stringify(this.toJson());
    }
}

export default Menu;