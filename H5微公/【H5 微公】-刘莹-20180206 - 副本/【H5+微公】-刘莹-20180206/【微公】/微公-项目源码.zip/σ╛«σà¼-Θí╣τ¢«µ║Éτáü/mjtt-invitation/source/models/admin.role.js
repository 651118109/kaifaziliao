import {ConstCode} from '../util/const';

/**
 * 后台列表对应的字段信息
 */
class AdminRoleInfo {

    constructor() {
        this.adminId = 0;
        this.username = "";
        this.rolename = "";
        this.status = ConstCode.NORMAL_ADMIN_STATUS;
        this.created = 0;
        this.updated = 0;
    }

    /**
     * 加载从数据库返回的结果集中加载数据
     * @param datas
     */
    loadFrom(datas) {
        if ( !datas ) {
            console.log("wrong datas: ", datas);
            return false;
        }

        this.adminId = datas["id"];
        this.username = datas["username"];
        this.rolename = datas["rolename"];
        this.status = datas["status"];
        this.created = datas["created"];
        this.updated = datas["updated"];
        return true;
    }

    toJson() {
        return {
            "adminId": this.adminId,
            "username": this.username,
            "rolename": this.rolename,
            "status": this.status,
            "created": this.created,
            "updated": this.updated
        };
    }

    toString() {
        return JSON.stringify(this.toJson());
    }

}

// 导出AdminRoleInfo
export default AdminRoleInfo;
