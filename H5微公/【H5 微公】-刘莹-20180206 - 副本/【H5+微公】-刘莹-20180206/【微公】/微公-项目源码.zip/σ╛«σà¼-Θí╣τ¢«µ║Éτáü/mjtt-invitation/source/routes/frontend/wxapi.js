
import express, {Router} from 'express';
import Config from '../../../config/config.json';
//import HttpClient from '../../util/http.client';
//import sha1 from 'js-sha1';
//import xmlParser from 'express-xml-bodyparser';
import middlewares from 'express-middlewares-js';


//import WxUserService from '../../service/wx.user.service';
//import {ConstCode} from '../../util/const';
//import InvitationUtil from './invitation.util';
import WeixinHandler from '../../util/wx.handler';
import Wechat from 'nodejs-wechat';

let router = new Router();
//let httpClient = new HttpClient();
//let followService = new FollowService();
//let wxUserService = new WxUserService();
//let invitationUtil = new InvitationUtil;

router.use('/', middlewares.xmlBodyParser({
    type: 'text/xml'
}));

let opt = {
    token: Config.token,
    url: '/wxapi'
};

let wechat = new Wechat(opt);

router.get('/', wechat.verifyRequest.bind(wechat));
router.post('/', wechat.handleRequest.bind(wechat));


// 收到文本消息
wechat.on('text', WeixinHandler.handleWeixinText);

// 关注|扫码关注|扫码带参数关注
wechat.on('event.subscribe', WeixinHandler.handleWeixinEventSubscribe);

// 扫码带参数进入
wechat.on('event.SCAN', WeixinHandler.handleWeixinEventScan);

// 扫码带参数进入
wechat.on('event.CLICK', WeixinHandler.handleWeixinEventClick);

/**
 * 检测sign
 * @param {*请求数据} req 
 * @param {*返回对象} res 
 */
 /*
let checkSign = (req, res) => {

    let signature = req.query.signature || "";
	let echostr = req.query.echostr || "";
	let timestamp = req.query.timestamp || "";
	let nonce = req.query.nonce || "";

	let hashcode = sha1([Config.token, timestamp, nonce].sort().join(""));
	console.log("hashcode: ", hashcode);
	if ( hashcode === signature ) {
        res.send(echostr);
        res.end();        
        return true;
    } else {
        res.end();
        return false;
    }
}
*/





/********router*********/

/**
 * 微信推送sign校验
 */
/*
router.get('/', (req, res, next) => {
    checkSign(req, res);
});
*
/

/**
 * 微信推送事件XML数据
 */

/*
router.post('/', xmlParser({trim: false, explicitArray: false}), (req, res, next) => {

    let content = req.body;
    console.log("xml: ", content);
    //if ( !checkSign(req, res) ) {
    //    console.error("check sign failed");
    //    return ;
    //}

    //事件分发
    if (content.xml.msgtype == "event") {
        if (content.xml.event == "subscribe") { //扫码关注公众号

            // 关注带参数扫码
            if (content.xml.eventkey === "qrscene_activity_invitation") {    //邀请卡活动
                scanInvitation(content.xml.fromusername);
            } else if (content.xml.eventkey.startsWith("qrscene_sharer_")) { //分享邀请卡
                scanShareInvitation(content.xml.eventkey.substring(15), content.xml.fromusername);
            } else if (content.xml.eventkey) {
                console.log("subscribe unknow eventkey: ", content.xml.eventkey);
                return;
            } 
        } else if (content.xml.event == "SCAN") {   //带参数扫码进入公众号

            //直接回复空
            res.end("");

            //继续后续逻辑
            if (content.xml.eventkey === "activity_invitation") {
                scanInvitation(content.xml.fromusername);
            } else if (content.xml.eventkey.startsWith("sharer_")) {
                scanShareInvitation(content.xml.eventkey.substring(7), content.xml.fromusername);
            } else {
                console.log("SCAN event cant find sharer openid. eventkey: ", content.xml.eventkey);
            }
        } else {
            console.log("unknowns event: ", content.xml.event);
            res.end("");
            return;
        }

    } else {
        console.log("unknowns msgtype:", content.xml.msgtype);
        res.end("");
    }    
    
});
*/




module.exports = router;