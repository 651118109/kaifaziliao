
let CommonUtil = () => {
};

/**
 * 生成分页相关数据
 * @param curPage 当前页
 * @param dataSize 数据记录条数
 * @param perPageSize 每页的条数
 */
CommonUtil.prototype.genPaginator = (curPage, dataSize, perPageSize) => {
    
    // 不允许为0
    if ( perPageSize === 0 ) {
        perPageSize = 1;
    }

    let pageSize = Math.ceil(dataSize / perPageSize);
    let prevPage = 1;
    let nextPage = 1;
    if ( pageSize > 0 ) {
        prevPage = (curPage - 1) <= 1 ? 1 : (curPage - 1);
        nextPage = (curPage + 1) > pageSize ? pageSize : (curPage + 1);
    }

    // 返回分页所需的数据
    return {
        pageSize: pageSize,
        prevPage: prevPage,
        nextPage: nextPage,
    }
};

/**
 * 生成指定长度的32位随机字符串
 * @param {*长度} length 
 */
let rawData = [
    '0','1', '2', '3', '4', '5', '6', '7', '8', '9', 
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 
    'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D',
    'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
    'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
    'Y', 'Z'];
CommonUtil.prototype.getRandomStr = (length)  => {
    let str = "";
    for ( let i=0; i<length; i++ ) {
        let index = parseInt(Math.random()*(rawData.length), 10);
        str += rawData[index];
    }
    return str;
}

export default CommonUtil;