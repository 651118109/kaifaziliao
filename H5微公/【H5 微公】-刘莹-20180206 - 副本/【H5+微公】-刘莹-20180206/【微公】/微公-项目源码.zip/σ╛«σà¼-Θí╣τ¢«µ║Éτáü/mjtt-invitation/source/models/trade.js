/**
 * Created by allen on 2017/4/1.
 * 对应数据库的backend.Admin表结构
 */
import {ConstCode} from '../util/const';
import {Codec} from '../util/codec';

let codec = new Codec();

class Trade {

    /**
     * 初始化字段内容
     */
    constructor() {
        this.orderId    = 0;
        this.tradeNo    = "";
        this.openId     = "";
        this.price      = 0.0;
        this.desc       = "";
        this.resultCode = "";
        this.errCode    = "";
        this.errCodeDes = "";
        this.created    = 0;
        this.updated    = 0;
    }

    /**
     * 从数据库返回的结果集中加载数据
     * @param datas 字典类型（数据库的数据）
     */
    loadFrom(datas) {
        console.log("trade datas: ", datas);
        this.orderId    = datas["orderId"];
        this.tradeNo    = datas["tradeNo"];
        this.openId     = datas["openId"];
        this.price      = datas["price"];
        this.desc       = datas["desc"];
        this.resultCode = datas["resultCode"];
        this.errCode    = datas["errCode"];
        this.errCodeDes = datas["errCodeDes"];
        this.created    = datas["created"];
        this.updated    = datas["updated"];
        return true;
    }

    /**
     * 返回一个json数据
     */
    toJson() {
        return {
            "orderId":  this.orderId,
            "tradeNo":  this.tradeNo,
            "openId":   this.openId,
            "price":    this.price,
            "desc":     this.desc,
            "resultCode": this.resultCode,
            "errCode":  this.errCode,
            "errCodeDes": this.errCodeDes,
            "updated":  this.updated
        };
    }

    /**
     * 返回一个stringify的json格式数据
     */
    toString() {
        return JSON.stringify(this.toJson());
    }

}

// 导出Admin
export default Trade;
