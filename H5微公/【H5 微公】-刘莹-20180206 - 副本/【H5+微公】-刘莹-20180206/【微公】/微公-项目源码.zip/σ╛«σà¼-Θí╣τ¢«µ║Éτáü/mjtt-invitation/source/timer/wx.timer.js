
import Config from '../../config/config.json';
import WxSetting from '../../config/wxsetting.json';
import HttpClient from '../util/http.client';

let httpClient = new HttpClient();

let WxTimer = () => {    
}

// 刷新全局token
let refreshAccessToken = () => {

    let url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + Config.appId + "&secret=" + Config.appSecret;
    
    httpClient.get(url)
    .then(content => {

        try {
            content = JSON.parse(content);        
        } catch (err) {
            console.error("parse body failed. body: ", content);
            return ;
        }

        let access_token = content.access_token || "";
        let expires_in = content.expires_in || 0;
        if ( access_token == "" ) {
            console.error("not correct response body content. content: ", content);
            return ;
        }

        global.access_token = access_token;
        console.log("access_token: ", global.access_token);

        if ( expires_in == 0 ) {
            console.log("expires_in is 0. do not open timer", expires_in);
            return ;
        }

        // 获取完token就获取ticket
        loadJSApiTicket();  

        // 超时时间内重新获取一次token
        setTimeout(() => {
            refreshAccessToken();
        }, expires_in * 1000);
    })
    .catch(err => {
        console.error("fetch access_token from wechat failed. error: ", err);        
    });
}

/**
 * 获取JS API ticket。每次都要带上token
 */
let loadJSApiTicket = () => {
    let url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=" + global.access_token + "&type=jsapi";
    console.log("request jsapi ticket url: ", url);
    httpClient.get(url)
    .then(content => {

        try {
            content = JSON.parse(content);        
        } catch (err) {
            console.error("parse body failed. body: ", content);
            return ;
        }
        
        let errcode = content.errcode || "";
        let errmsg = content.errmsg || "";
        let ticket = content.ticket || "";

        if (errcode == 0  && errmsg == "ok" && ticket != "") {
            global.jsapi_ticket = ticket;
        } else {
            console.error("not correct response body content. body: ", content);
        }
    })
    .catch(err => {
        console.error("fetch access_token from wechat failed. error: ", err);
    });
}

let loadWxReplySetting = () => {

    //let url = "https://sh.api.weixin.qq.com/cgi-bin/get_current_autoreply_info?access_token=" + global.access_token;
    //httpClient.get(url)
    //.then(content => {

    //    try {
    //        content = JSON.parse(content);        
    //    } catch (err) {
    //        console.error("parse body failed. body: ", content);
    //        return ;
    //    }

        global.AutoReplySetting = WxSetting.autoReply;
        
    //})
    //.catch(err => {
    //    console.error("fetch replySetting from wechat failed. error: ", err);
    //});
}
/*
let createWxMenuButton = (info) => {

    if (info.type === "view") {

        let button = {
            "name" : info.name,
            "type" : info.type,
            "url" : info.url
        }
        return button;

    } else if (info.type === "news"
            || info.type === "img"
            || info.type === "voice") {

        let button = {
            "name" : info.name,
            "type" : "media_id",
            "media_id" : info.value
        }

        return button;

    } else if (info.type === "text") {

        let button = {
            "name" : info.name,
            "type" : "click",
            "key" : info.value
        }

        return button;

    }
}
*/

let UpdateWxMenu = () => {

    
    if (WxSetting.menu_info_update != 1) 
        return;

    let createMenuUrl = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=" + global.access_token;
    let createMenuParam = WxSetting.menu_info;

    console.log("[menu param]:\n", createMenuParam);

    httpClient.post(createMenuUrl, createMenuParam)
    .then (content => {
        console.log(content);
    })
    .catch(err => {
        console.error("fetch access_token from wechat failed. error: ", err);        
    });
}

/**
 * 获取微信AccessToken
 */
WxTimer.prototype.loadWxAccessToken = () => {

    let url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + Config.appId + "&secret=" + Config.appSecret;
    
    httpClient.get(url)
    .then(content => {

        try {
            content = JSON.parse(content);        
        } catch (err) {
            console.error("parse body failed. body: ", content);
            return ;
        }

        let access_token = content.access_token || "";
        let expires_in = content.expires_in || 0;
        if ( access_token == "" ) {
            console.error("not correct response body content. content: ", content);
            return ;
        }

        global.access_token = access_token;
        console.log("access_token: ", global.access_token);

        if ( expires_in == 0 ) {
            console.log("expires_in is 0. do not open timer", expires_in);
            return ;
        }

        // 获取完token就获取ticket
        loadJSApiTicket();	

        // 获取自动回复规则		
        loadWxReplySetting();

        // 获取菜单配置
        UpdateWxMenu();

        // 超时时间内重新获取一次token
        setTimeout(() => {
            refreshAccessToken();
        }, expires_in * 1000);
    })
    .catch(err => {
        console.error("fetch access_token from wechat failed. error: ", err);        
    });
}

export default WxTimer;