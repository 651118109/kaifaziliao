
import express, {Router} from 'express';
import AdminService from '../../service/admin.service';


let router = new Router();
let adminService = new AdminService();

/**
 * 跳转到admin列表页面
 */
router.get('/list', (req, res, next) => {
    res.render('backend/user/admin.list.ejs', {});
});

/**
 * 跳转到admin添加列表页面
 */
router.get('/add', (req, res, next) => {
    res.render('backend/user/admin.add.ejs', {});
});

/**
 * 跳转到admin编辑列表页面
 */
router.get('/edit', (req, res, next) => {
    let adminId = req.query.adminId || 0;
    adminService.getById(adminId).then(result => {
        // 跳转到edit页面
        res.render('backend/user/admin.edit.ejs', {'admin': result.toJson()});
    }).catch(err => {
        let error = new Error("err: ", err);
        next(error);
    });
});

module.exports = router;