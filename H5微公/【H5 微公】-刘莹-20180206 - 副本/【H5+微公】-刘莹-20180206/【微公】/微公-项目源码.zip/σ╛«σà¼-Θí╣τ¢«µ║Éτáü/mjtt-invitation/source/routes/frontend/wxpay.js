import express, {Router} from 'express';
import Config from '../../../config/config.json';
import WxpayConfig from '../../../config/wxpay.config.json';
import HttpClient from '../../util/http.client';
import CommonUtil from '../../util/common.util'
import Trade from '../../models/trade';
import TradeService from '../../service/trade.service';
import InviCodeService from '../../service/invicode.service';
import sha1 from 'js-sha1';
import xmlParser from 'express-xml-bodyparser';
import xml2js from 'xml2js';
import moment from 'moment';
import crypto from 'crypto';

let router = new Router();
let httpClient = new HttpClient();
let commonUtil = new CommonUtil();
let tradeService = new TradeService();
let inviCodeService = new InviCodeService();

/**
 * 根据微信的加签规则生成签名
 * @param {*dict} params 
 */
let makeSign = (params) => {

    if ( !params ) {
        return "";
    }
    // step1: 对params根据key按照ascii码排序
    let sortedKeys = Object.keys(params).sort();
    let str = "";
    for ( let i=0; i<sortedKeys.length; i++ ) {
        if ( sortedKeys[i] == "sign" ) continue; // sign不加签
        if ( params[sortedKeys[i]] != "" && params[sortedKeys[i]] != undefined ) {
            str += sortedKeys[i] + "=" + params[sortedKeys[i]] + "&";
        }
    }
    str += "key=" + WxpayConfig.signKey;
    console.log("sorted str: ", str, ", params: ", params, ", key: ", WxpayConfig.signKey);

    let md5 = crypto.createHash('md5');
    return md5.update(str).digest('hex').toUpperCase();
}

/**
 * 提交订单信息到微信
 * @param {*商户订单号} tradeNo 
 * @param {*总价格 单位分，整形} totalFee 
 * @param {*客户端remoteIp} remoteIp 
 */
let submitOrder = (tradeNo, totalFee, remoteIp) => {
    let noncestr = commonUtil.getRandomStr(32);
    let param = {
        "appid": Config.appId,
        "mch_id": WxpayConfig.merchantId,
        "nonce_str": noncestr,
        "body": WxpayConfig.desc,
        "out_trade_no": tradeNo,
        "total_fee": parseInt(totalFee),
        "spbill_create_ip": remoteIp,
        "notify_url": WxpayConfig.postOrderUrl,
        "trade_type": "JSAPI"
    };
    param["sign"] = makeSign(param);

    // 转换为xml
    let builder = new xml2js.Builder();
    let data = builder.buildObject(param);
    data = data.replace(/root/g, 'xml');
    console.log("data: ", data);

    return httpClient.postXML(WxpayConfig.unifiedorder, data);
};

// 获取客户端IP
let getClientIP = (req) => {
    console.log("req.headers['x-forwarded-for']: ", req.headers['x-forwarded-for']);
    console.log("req.connection.remoteAddress: ", req.connection.remoteAddress);
    let ip = req.headers['x-forwarded-for'] ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    req.connection.socket.remoteAddress;
    return ip.split(',')[0];
}

/**
 * 用户发起支付邀请码
 * 先生成订单号，再向微信发起支付申请
 * 拿到prepay_id 生成 paysign
 * 拿到prepay_id 生成 paysign
 */
router.get('/preorder', (req, res, next) => {

    httpClient.post(WxpayConfig.mjttPreOrder, {
        "openid": req.session.open_id
    })
    .then( result => {

        console.log("wxpay result: ", result.data);

        if ( result.code != 0 ) {
            console.log("wrong wxpay result: ", result);
            return res.json({
                code: 500,
                result: {
                    message: '支付接口错误',
                    msg: err
                }
            });
        }

        if ( !result.data ) {
            return res.json({
                code: 500,
                result: {
                    message: '支付接口错误',
                    msg: err
                }
            });
        }

        let param = {
            "code": 200,
            "appId": result.data.appId,
            "timeStamp": result.data.timeStamp,
            "nonceStr": result.data.nonceStr,
            "package": result.data.package,
            "paySign": result.data.paySign,
            "signType": result.data.signType,
        }
        res.json(param);
    })
    .catch( err => {
        console.error("err: ", err);
        res.json({
            code: 500,
            result: {
                message: '支付接口错误',
                msg: err
            }
        });
    });    
});

/**
 * 微信通知订单完成
 * 对订单做去重处理
 */
router.post('/postorder', (req, res, next) => {

    console.log("postorder req.body: ", req.body);

    let candidate = makeSign(req.body);
    if ( candidate != req.body.sign ) {
        console.error("sign not match. candidate: ", candidate, ", sign: ", sign);
        return ;
    }

    let transaction_id = req.body.transactionId || "";    
    let user_openid = req.body.openId || "";

    let message_url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + global.access_token;

    inviCodeService.buyCode(transaction_id, user_openid)
    .then(invitcode => {
        
        let param = {
            "touser": user_openid,
            "msgtype":"text",
            "text":
            {
                 "content": invitcode
            }
        }

        return httpClient.post(message_url, param);
    })
    .then(result => {
                    
        console.log("result for send code: ", result);
        let content = global.template.buyCode;        
        let param = {
            "touser": user_openid,
            "msgtype":"text",
            "text":
            {
                 "content": content
            }
        }
        return httpClient.post(message_url, param);
    })
    .then( result => {
        console.log("send buy code template message result: ", result);
    })
    .catch(err => {
        console.error("buy code error: ", err);
    });

    res.json({
        "return_code": "SUCCESS",
        "return_msg": "OK"
    });

});

/**
 * 查询订单状态信息
 */
router.get('/query', (req, res, next) => {

    let out_trade_no = "111";
    let param = {
        "appid": Config.appId,
        "mch_id": WxpayConfig.merchantId,
        "out_trade_no": out_trade_no,
        "nonce_str": commonUtil.getRandomStr(32)
    };
    param["sign"] = makeSign(param);

    let builder = new xml2js.Builder();
    let data = builder.buildObject(param);
    data = data.replace(/root/g, 'xml');
    console.log("data: ", data);
   
    httpClient.postXML(WxpayConfig.orderquery, data)
    .then( content => {
        return new Promise((resolved, rejected) => {
            xml2js.parseString(content, { explicitArray : false, ignoreAttrs : true }, (err, result) => {

                if ( !!err ) {
                    console.error("parse xml failed. err: ", err);
                    rejected(err);
                    return ;
                }
                console.log("result: ", result);
                resolved(result.xml);
            });
        });  
    })
    .then( content => {
        
        // 验证签名
        let sign = content.sign;
        let candidate = makeSign(content);
        if ( sign != candidate ) {
            console.error("sign not match. sign: ", sign, ", candidate: ", candidate);
            return res.json({
                code: 500,
                result: {
                    message: '支付订单查询错误',
                    msg: err
                }
            });
        }
        if ( content.result_code != "SUCCESS" ) {
            return res.json({
                code: 500,
                result: {
                    message: '支付订单查询错误',
                    msg: content.err_code_des
                }
            });
        }
        console.log("content: ", content);
        res.json(content);
    })
    .catch(err => {
        console.error("payment err: ", err);
        res.json({
            code: 500,
            result: {
                message: '支付订单查询错误',
                msg: err
            }
        });
    });
});

module.exports = router;