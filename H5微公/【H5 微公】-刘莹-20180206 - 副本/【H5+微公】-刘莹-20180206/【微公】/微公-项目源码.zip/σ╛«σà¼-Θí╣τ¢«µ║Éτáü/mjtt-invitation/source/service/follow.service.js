
import Follow from '../models/follow';
import {ConstCode} from '../util/const';
import {ERRCODE} from '../util/errcode';
import DBHelper from '../db/mysql.connector';

/**
 * 关注信息查询
 */
class FollowService {

    /**
     * 添加一条关注记录
     * @param {*关注记录 } follow 
     */
    add(follow) {
        return new Promise((resolved, rejected) => {
            if ( !follow ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection().then(connection => {

                let sql = "INSERT INTO follow (userOpenId, friOpenId, created, updated) VALUES (?, ?, ?, ?)";
                let params = [
                    follow.userOpenId,
                    follow.friOpenId,
                    follow.created,
                    follow.updated
                ];

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release();
                    console.log("last inserted follow id: ", result.insertId);
                    resolved(result);
                });

            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 获取openId的用户的关注用户
     * @param {*用户的openId} userOpenId 
     */
    getCount(userOpenId) {
        return new Promise((resolved, rejected) => {

            if ( !userOpenId ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection().then(connection => {
                
                let sql = "SELECT count(followId) as count FROM follow WHERE userOpenId = ?";
                let params = [userOpenId];

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release();
                    console.log(result);
                    resolved(result[0]["count"]);
                });

            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });

        });
    }

}

export default FollowService;