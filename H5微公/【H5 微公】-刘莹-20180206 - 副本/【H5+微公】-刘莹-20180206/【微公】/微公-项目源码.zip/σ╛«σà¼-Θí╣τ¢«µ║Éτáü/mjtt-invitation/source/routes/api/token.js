import express, {Router} from 'express';
import {ERRCODE} from '../../util/errcode';
import QiniuConfig from '../../../config/qiniu.json';
import Qiniu from 'qiniu';

let router = new Router();
let mac = new Qiniu.auth.digest.Mac(QiniuConfig.AK, QiniuConfig.SK);

/**
 * 获取七牛token
 */
router.get('/', (req, res, next) => {

    // 返回信息
    let putPolicy = new Qiniu.rs.PutPolicy({
        scope: QiniuConfig.Bucket
    });
    return res.jsonp({
        uptoken: putPolicy.uploadToken(mac)
    });
    
});

module.exports = router;