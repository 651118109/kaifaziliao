
import TemplateMessage from '../models/template.message';
import {ConstCode} from '../util/const';
import {ERRCODE} from '../util/errcode';
import DBHelper from '../db/mysql.connector';

/**
 * 关注信息查询
 */
class TemplateMessageService {

    /**
     * 根据模版消息ID获取模版消息
     * @param {*模版ID } templateId 
     */
    get(templateId) {
        return new Promise((resolved, rejected) => {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND).then((connection) => {
                let sql = "SELECT * FROM template_message WHERE templateId = ? LIMIT 1";
                return DBHelper.query(connection, sql, [templateId]).then((result) => {
                    if (!result) {
                        console.error("exec sql:", sql, " with undefined result!");
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    if ( result.length <= 0 ) {
                        console.error("exec sql: ", sql, " has not result!");
                        connection.release();
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    let templateMessage = new TemplateMessage();
                    if ( !templateMessage.loadFrom(result[0]) ) {
                        console.log("load datas to templateMessage object failed");
                        connection.release();
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    connection.release();
                    resolved(templateMessage);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        })
    }

    /**
     * 传入id数组获取template数组
     * @param [Array] templateIds
     */
    getList(templateIds) {
        return new Promise((resolved, rejected) => {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND).then((connection) => {
                let sql = "SELECT * FROM template_message WHERE templateId in (?)";
                let ids = "'" + templateIds.join("','") + "'";

                console.log("exec sql: ", sql, ", param: ", ids);

                return DBHelper.query(connection, sql, [ids]).then((result) => {
                    connection.release(); // 释放链接                    
                    let datas = [];
                    for (let i=0; i<result.length; i++) {
                        let template = new TemplateMessage();
                        if ( !template.loadFrom(result[i]) ) {
                            continue;
                        }
                        datas.push(template);
                    }
                    resolved(datas);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        })
    }

    /**
     * 分页搜索
     * @param {*} curPage 
     * @param {*} count 
     * @param {*} content 
     */
    searchWithPaginator(curPage, count, content) {
        return new Promise((resolved, rejected) => {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
            .then(connection => {

                let sql = "SELECT * FROM template_message";
                let params = [];

                if ( content ) {
                    let condition = '%' + content + '%';
                    sql += " WHERE ( name like ?  OR content like ? OR templateId like ?)";
                    params = params.concat([], [condition, condition, condition]);
                }

                sql += " ORDER BY templateId DESC LIMIT ? OFFSET ?";
                params = params.concat([], [count, (curPage - 1) * count]);

                // 执行查询操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release(); // 释放链接
                    let datas = [];
                    for (let i=0; i<result.length; i++) {
                        let template = new TemplateMessage();
                        if ( !template.loadFrom(result[i]) ) {
                            continue;
                        }
                        datas.push(template);
                    }
                    resolved(datas);
                });
            })
            .catch(err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 获取记录条数
     * @param {*} curPage 
     * @param {*} count 
     * @param {*} content 
     */
    getSizeWithContent(curPage, count, content) {
        return new Promise((resolved, rejected) => {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
            .then(connection => {

                let sql = "SELECT count(templateId) as count FROM template_message";
                let params = [];

                if ( content ) {
                    let condition = '%' + content + '%';
                    sql += " WHERE ( name like ?  OR content like ? OR templateId like ?)";
                    params = params.concat([], [condition, condition, condition]);
                }

                // 执行查询操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release(); // 释放链接
                    console.log(result);
                    resolved(result[0]["count"]);
                });
            })
            .catch(err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 添加一条关注记录
     * @param {*关注记录 } follow 
     */
    add(templateMessage) {
        return new Promise((resolved, rejected) => {
            if ( !templateMessage ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            // 构建templateId
            templateMessage.templateId = "TEMPLATE_" + new Date().getTime();

            return DBHelper.getConnection().then(connection => {

                let sql = "INSERT INTO template_message (templateId, name, content, status, created, updated) VALUES (?, ?, ?, ?, ?, ?)";
                let params = [
                    templateMessage.templateId,
                    templateMessage.name,
                    templateMessage.content,
                    templateMessage.status,
                    templateMessage.created,
                    templateMessage.updated
                ];

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release();
                    console.log("last inserted template message id: ", result.insertId);
                    resolved(result);
                });

            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 修改模版消息类型
     * @param {*模版消息类 } templateMessage 
     */
    modify(templateMessage) {
        return new Promise((resolved, rejected) => {
            if ( !templateMessage ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection().then(connection => {

                let sql = "UPDATE template_message SET name=?, content=?, status=?, updated=? WHERE templateId=?";
                let params = [
                    templateMessage.name,
                    templateMessage.content,
                    templateMessage.status,
                    templateMessage.updated,
                    templateMessage.templateId
                ];

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release(); // 释放链接
                    console.log("update template message result: ", result);
                    resolved(result);
                });

            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    del(templateId) {
        return new Promise((resolved, rejected) => {
            if ( !templateId ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection().then(connection => {

                let sql = "DELETE FROM template_message WHERE templateId = ? LIMIT 1";
                let params = [
                    templateId
                ];

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release(); // 释放链接
                    console.log("delete template message result: ", result);
                    resolved(result);
                });

            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

}

export default TemplateMessageService;