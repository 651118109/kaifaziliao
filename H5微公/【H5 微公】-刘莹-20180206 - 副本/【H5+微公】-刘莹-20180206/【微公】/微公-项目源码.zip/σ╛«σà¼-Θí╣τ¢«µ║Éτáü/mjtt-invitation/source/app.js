// 程序入口
import express from 'express';
import path from 'path';
import logger from 'morgan';
import cookieParser from 'cookie-parser';
import expressSession from 'express-session';
import mysqlSession from 'express-mysql-session';
import bodyParser from 'body-parser';
import database from '../config/database.json';
import WxTimer from './timer/wx.timer';
import ActivityConfigService from './service/activity.config.service';
import TemplateMessageService from './service/template.message.service';
import {ConstCode} from './util/const';
import Config from '../config/config.json';

let app = new express();
let MySQLStore = new mysqlSession(expressSession);

app.set('views', path.join(__dirname, "../views"));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(cookieParser());
app.use(expressSession({
    key: "session_cookie_name",
    secret: 'boom-shaka-laka',
    // cookie: { maxAge: 15 * 86400 * 1000 } // 默认保存15天， cookie
    store: new MySQLStore(database.mjtt),
    resave: false,
    saveUninitialized:false
}));
app.use(express.static(path.join(__dirname, "../public")));

/**
 * 转发缓存拦截。（保证 ejs 模板能取到）
 */
app.use(function (req, res, next) {
    res.locals.session = req.session;
    next();
});

// --> begin 设定前端页面路由 <--
import FrontendIndex from './routes/frontend/index';
import FrontendWx from './routes/frontend/wxapi';
import FrontendWxPay from './routes/frontend/wxpay';
app.use('/', FrontendIndex);
app.use('/wxapi', FrontendWx);
app.use('/wxpay', FrontendWxPay);
// --> end 设定前端页面路由 <--

// --> begin 设定API路由 <--
import ApiUserAction from './routes/api/user.action';
import ApiRole from './routes/api/role';
import ApiUser from './routes/api/user';
import ApiActivity from './routes/api/activity';
import ApiToken from './routes/api/token';
import ApiTemplate from './routes/api/template';
app.use('/api/userAction', ApiUserAction);
app.use('/api/role', ApiRole);
app.use('/api/user', ApiUser);
app.use('/api/activity', ApiActivity);
app.use('/api/token', ApiToken);
app.use('/api/template', ApiTemplate);
// --> end 设定API路由 <--

// 登录拦截器
app.use(function (req, res, next) {
    let url = req.originalUrl;
    console.log(req.originalUrl);
    // 如果是访问后台页面
    if ( req.url.indexOf("/admin") === 0 ) {

        if (req.url === "/admin/login") {
            return next();
        }

        if (!req.session.user) {
            return res.redirect("/admin/login");
        }

    }    
    next();
});


//--> begin 设定后台路由 <--
import BackendIndex from './routes/backend/index';
import BackendLogin from './routes/backend/login';
import BackendRole from './routes/backend/role';
import BackendUser from './routes/backend/user';
import BackendActivity from './routes/backend/activity';
import BackendTemplate from './routes/backend/template';
app.use('/admin', BackendIndex);
app.use('/admin/login', BackendLogin);
app.use('/admin/role', BackendRole);
app.use('/admin/user', BackendUser);
app.use('/admin/activiy', BackendActivity);
app.use('/admin/template', BackendTemplate);
//--> end 设定后台路由 <--

// 404 handler
app.use((req, res, next) => {
    let err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// 错误信息handler
app.use((err, req, res, next) => {
    res.status(err.status || 500);
    // 记录错误信息，跳转到页面
    console.error(err);
    let errmsg = { // 默认为5xx异常
        code: err.status,
        title: '服务器异常',
        content: '服务器发生异常，请联系管理员',
    };
    if ( err.status === 403 ) {
        errmsg.code = 403;
        errmsg.title = '访问拒绝';
        errmsg.content = '您没有权限访问该页面，请联系管理员';
    } else if ( err.status === 404 ) {
        errmsg.code = 404;
        errmsg.title = '找不到页面';
        errmsg.content = '您访问的页面不存在，请联系管理员';
    }
    res.render('error.ejs', {err: errmsg});
});

// 加载微信的accessToken
let wxtimer = new WxTimer();
wxtimer.loadWxAccessToken();


// 获取美景后台配置
let activtyConfigService = new ActivityConfigService();
let templateService = new TemplateMessageService();
let refreshActivityConfig = () => {

    Promise.all([

        activtyConfigService.getConfig(ConstCode.CONFIG_ACTIVITY),
        templateService.get(Config.template.intro),
        templateService.get(Config.template.getCode),
        templateService.get(Config.template.buyCode),
        templateService.get(Config.template.getHelp),
        templateService.get(Config.template.getHelpComplete),
        templateService.get(Config.template.followHelp),
        templateService.get(Config.template.achieve)
    ])
    .then(results => {
        //console.log("results: ", results);

        global.activity = results[0];
        global.template = {
            intro:results[1].content,
            getCode:results[2].content,
            buyCode:results[3].content,
            getHelp:results[4].content,
            getHelpComplete:results[5].content,
            followHelp:results[6].content,
            achieve:results[7].content
        }
    })
    .catch ( err => {
        console.error(err);
    }) 
}

// 获取活动配置(每隔10秒刷新一次)
refreshActivityConfig();
setInterval(refreshActivityConfig, 600*1000);


module.exports = app;






