
import express, {Router} from 'express';
import {ConstCode} from '../../util/const';
import ActivityConfigService from '../../service/activity.config.service';

let router = new Router();
let activityConfigService = new ActivityConfigService();

/**
 * 获取配置信息，并渲染页面
 */
router.get('/invite', (req, res, next) => {
    
    // 获取配置信息，然后渲染页面
    activityConfigService.getConfig(ConstCode.CONFIG_ACTIVITY)
    .then(config => {
        res.render('backend/activity/config.invite.ejs', {
            'config': config
        });
    })
    .catch(err => {
        let error = new Error("err: ", err);
        next(error);
    });
});

module.exports = router;