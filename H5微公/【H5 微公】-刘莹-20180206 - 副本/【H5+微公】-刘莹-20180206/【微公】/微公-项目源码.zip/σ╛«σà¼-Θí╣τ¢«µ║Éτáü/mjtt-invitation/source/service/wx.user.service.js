
import WxUser from '../models/wx.user';
import {ConstCode} from '../util/const';
import {ERRCODE} from '../util/errcode';
import DBHelper from '../db/mysql.connector';

class WxUserService {

    constructor() {        
    }
    
    /**
     * 根据openId获取用户信息
     * @param {*微信openId} openId 
     */
    get(openId) {
        // 返回一个promise对象
        return new Promise((resolved, rejected) =>  {
            return DBHelper.getConnection()
                .then(connection => {

                let sql = "SELECT * FROM wx_user WHERE openId = ? LIMIT 1";
                let params = [openId];
                return DBHelper.query(connection, sql, params).then((result) => {
                    if (!result) {
                        console.error("exec sql:", sql, " with undefined result!");
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    if ( result.length <= 0 ) {
                        console.error("exec sql: ", sql, " with param: ", params, " has not result!");
                        connection.release();
                        resolved(null);
                        return ;
                    }
                    let wxUser = new WxUser();
                    if ( !wxUser.loadFrom(result[0]) ) {
                        console.log("load datas to wxUser object failed");
                        connection.release();
                        rejected(ERRCODE.SYSTEM_ERROR);
                        return ;
                    }
                    connection.release();
                    resolved(wxUser);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 添加一个微信用户
     * @param {*微信用户} wxUser 
     */
    add(wxUser) {
        return new Promise((resolved, rejected)=>{

            console.log("wxuser: ", wxUser);

            if ( !wxUser ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection().then(connection => {

                let sql = "INSERT INTO wx_user (openId, inviteCode, status, created, updated) VALUES (?, ?, ?, ?, ?)";
                let params = [
                    wxUser.openId,
                    wxUser.inviteCode,
                    wxUser.status,
                    wxUser.created,
                    wxUser.updated
                ];

                console.log("exec sql: ", sql, " with params: ", params);

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release();
                    console.log("last inserted wxUser id: ", result.insertId);
                    resolved(result);
                });

            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

    /**
     * 修正微信用户信息
     * @param {*微信用户 } wxUser 
     */
    modify(wxUser) {
        return new Promise((resolved, rejected)=>{
            if ( !wxUser ) {
                rejected(ERRCODE.PARAMETER_ERROR);
                return ;
            }

            return DBHelper.getConnection().then(connection => {

                let sql = "UPDATE wx_user SET inviteCode=?, status=?, updated=? WHERE openId=? LIMIT 1";
                let params = [
                    wxUser.inviteCode,
                    wxUser.status,
                    new Date().getTime(),
                    wxUser.openId
                ];

                // 执行操作
                return DBHelper.query(connection, sql, params).then(result => {
                    connection.release();
                    console.log("result: ", result);
                    resolved(result);
                });
            }).catch( err => {
                console.error(err);
                rejected(ERRCODE.SYSTEM_ERROR);
            });
        });
    }

}

// 导出AdminManager
export default WxUserService;
