
class TemplateMessage {

    /**
     * 初始化字段内容
     */
    constructor() {
        this.templateId = "";        
        this.name = ""; // 用户openId
        this.content = "";  // 好友openId
        this.status = 0;
        this.created = 0;
        this.updated = 0;
    }

    /**
     * 从数据库返回的结果集中加载数据
     * @param datas 字典类型（数据库的数据）
     */
    loadFrom(datas) {
        //console.log("template message datas: ", datas);
        this.templateId = datas["templateId"];
        this.name = datas["name"];
        this.content = datas["content"];
        this.status = datas["status"];
        this.created = datas["created"];
        this.updated = datas["updated"];
        return true;
    }

    /**
     * 返回一个json数据
     */
    toJson() {
        return {
            "templateId": this.templateId,
            "name": this.name,
            "content": this.content,
            "status": this.status,
            "created": this.created,
            "updated": this.updated
        };
    }

    /**
     * 返回一个stringify的json格式数据
     */
    toString() {
        return JSON.stringify(this.toJson());
    }

}

// 导出WxUser
export default TemplateMessage;