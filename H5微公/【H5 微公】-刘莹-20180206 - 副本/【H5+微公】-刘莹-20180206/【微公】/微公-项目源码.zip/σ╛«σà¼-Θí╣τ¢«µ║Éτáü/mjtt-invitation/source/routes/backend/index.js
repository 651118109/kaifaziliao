
import express, {Router} from 'express';

let router = new Router();

/**
 * index默认路由
 */
router.get('/', (req, res, next) => {
    res.redirect('/admin/dashboard');
});

/**
 * 显示dashboard页面
 */
router.get('/dashboard', (req, res, next) => {
    console.log("req.session.user: ", req.session.user);
    res.render('backend/dashboard.ejs', {});
});

/**
 * 跳转到密码修改页面
 */
router.get('/changePwd', (req, res, next) => {
    res.render('backend/user/change.pwd.ejs', {});
});

/**
 * 退出登录
 */
router.get('/logout', (req, res, next) => {
    req.session.user = undefined;
    return res.redirect('/admin/login');
});

module.exports = router;