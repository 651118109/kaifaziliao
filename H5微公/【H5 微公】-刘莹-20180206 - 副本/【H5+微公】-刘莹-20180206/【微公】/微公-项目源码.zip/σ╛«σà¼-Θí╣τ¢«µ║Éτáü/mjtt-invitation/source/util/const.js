
let ConstCode = {

    CONFIG_ACTIVITY: "activity",    // 活动配置

    VALID_RECORD: 0,        // 正常的数据库记录状态
    INVALID_RECORD: 1,      // 非正常的数据库记录状态

    NORMAL_ADMIN_STATUS: 0, // 正常的管理员状态

    PAGE_DEFAULT_COUNT: 100,         // 每页显示的数据条数

    ACTIVITY_NOT_APPLY: 0,      // 活动过未申请
    ACTIVITY_APPLYING:  1,      // 活动申请中
    ACTIVITY_END_APPLY: 2,      // 已申请

};

module.exports.ConstCode = ConstCode;