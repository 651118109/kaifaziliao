import express, {Router} from 'express';
import {ERRCODE} from '../../util/errcode';
import {ConstCode} from '../../util/const';
import ActivityConfigService from '../../service/activity.config.service';

let router = new Router();
let activityConfigService = new ActivityConfigService();

/**
 * 更新配置信息
 */
router.post('/invite/edit', (req, res, next) => {

    let configName = req.body.configName || "";
    let banner = req.body.banner || "";
    let goodsBanner = req.body.goodsBanner || "";
    let qrcodeBG = req.body.qrcodeBG || "";
    let price = req.body.price || 0;
    let fpcount = req.body.fpcount || 0;

    // step0: 校验参数
    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    activityConfigService.getConfig(ConstCode.CONFIG_ACTIVITY)
    .then(config => {

        config.banner = banner;
        config.goodsIntroBanner = goodsBanner;
        config.qrcodeBG = qrcodeBG;
        config.price = price;
        config.needFPCount = fpcount;

        // 更新配置
        console.log("config tobe saved: ", config);
        return activityConfigService.modify(config);
    })
    .then( result => {
        res.json(resp);
    })
    .catch(err => {
        let error = new Error("err: ", err);
        next(error);
    });

});

module.exports = router;