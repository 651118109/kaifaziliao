
import express, {Router} from 'express';

import RoleService from '../../service/role.service';
import MenuService from '../../service/menu.service';

let router = new Router();
let menuService = new MenuService();
let roleService = new RoleService();

/**
 * 跳转到角色列表页面
 */
router.get('/list', (req, res, next) => {
    res.render('backend/role/role.list.ejs', {});
});

/**
 * 跳转到角色添加页面
 */
router.get('/add', (req, res, next) => {
    // 获取所有菜单信息
    menuService.getAllMenus()
    .then(menus => {
        console.log("menus: ", menus);
        return res.render('backend/role/role.add.ejs', {
            menus: menus
        });
    })
    .catch(err => {
        console.log("err: ", err);
        let error = new Error("err: ", err);
        next(error);
    });
});

/**
 * 跳转到角色编辑页面
 */
router.get('/edit', (req, res, next) => {

    let roleId = req.query.roleId || 0;
    Promise.all([
        roleService.getById(roleId),
        menuService.getAllMenus()
    ]).then(results => {
        console.log("results: ", results);
        let role = results[0];
        let menus = results[1];
        console.log(role.menuIds.split(","));
        return res.render('backend/role/role.edit.ejs', {
            role: role,
            checkedMenus: role.menuIds.split(","),
            menus: menus
        });
    }).catch(err => {
        console.log("err: ", err);
        let error = new Error("err: ", err);
        next(error);
    });
});

module.exports = router;