
import express, {Router} from 'express';
import {ERRCODE} from '../../util/errcode';
import AdminService from '../../service/admin.service';
import RoleService from '../../service/role.service';

let router = new Router();
let adminService = new AdminService();
let roleService = new RoleService();

/**
 * 处理登录API
 */
router.post('/login', (req, res, next) => {

    let username = req.body.username || "";
    let password = req.body.password || "";

    // 返回结果
    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    // step1: 检测是否存在该用户名
    let admin;
    adminService.getByUsername(username).then((data) => {

        admin = data;
        // step2: 检测用户名对应的密码是否正确(md5之后的值)
        if ( !admin.checkPassword(password) ) {
            console.error("password error!");
            resp.code = ERRCODE.PASSWORD_NOT_CORRECT_ERROR;
            return res.json(resp);
        }

        // 获取用户角色的menuIds
        return roleService.getById(admin.roleId);

    }).then(role => {

        // step3: 更新session
        req.session.user = {
            userId:  admin.adminId,
            username: admin.username,
            menus: role.menuIds.split(",")
        };

        // step4: 返回成功信息
        res.json(resp);

     }).catch(err => {
        console.error("login post action err: ", err);
        resp.code = err;
        return res.json(resp);
    });
});

/**
 * 修改密码
 */
router.post('/changePwd', (req, res, next) => {

    let oldPassword = req.body.oldPassword || "";
    let newPassword = req.body.newPassword || "";

    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    if ( oldPassword === newPassword ) {
        resp.code = ERRCODE.PARAMETER_ERROR;
        return res.jsonp(resp);
    }

    // 先获取用户信息
    adminService.getById(req.session.user.userId)
    .then(user => {
        // 先判断旧密码是否正确
        if ( !user.checkPassword(oldPassword) ) {
            resp.code = ERRCODE.PASSWORD_NOT_CORRECT_ERROR;
            return res.jsonp(resp);
        }
        // 设置密码并更新
        user.setPassword(newPassword);
        return adminService.changePassword(user);
    })
    .then(result => {
        console.log("update admin result: ", result);
        res.jsonp(resp);
    })
    .catch(err => {
        console.error("get admin by id error: ", err);
        resp.code = ERRCODE.SYSTEM_ERROR;
        return res.jsonp(resp);
    });

});

module.exports = router;