
class ActivityConfig {
    
    /**
     * 初始化字段内容
     */
    constructor() {
        this.configName = "";
        this.banner = "";               // 活动页Banner
        this.goodsIntroBanner = "";     // 商品描述
        this.qrcodeBG = "";             // 二维码背景图
        this.price = 0.0;               // 活动价格
        this.needFPCount = 0;           // 需要的好友力
        this.created = 0;
        this.updated = 0;
    }

    /**
     * 从数据库返回的结果集中加载数据
     * @param datas 字典类型（数据库的数据）
     */
    loadFrom(datas) {
        console.log("activity config datas: ", datas);
        this.configName = datas["configName"];
        this.banner = datas["banner"];
        this.goodsIntroBanner = datas["goodsIntroBanner"];
        this.qrcodeBG = datas["qrcodeBG"];        
        this.price = datas["price"];
        this.needFPCount = datas["needFPCount"];
        this.created = datas["created"];
        this.updated = datas["updated"];
        return true;
    }

    /**
     * 返回一个json数据
     */
    toJson() {
        return {
            "configName": this.configName,
            "banner": this.banner,
            "goodsIntroBanner": this.goodsIntroBanner,
            "qrcodeBG": this.qrcodeBG,            
            "price": this.price,
            "needFPCount": this.needFPCount,
            "updated": this.updated
        };
    }

    /**
     * 返回一个stringify的json格式数据
     */
    toString() {
        return JSON.stringify(this.toJson());
    }

}

// 导出WxUser
export default ActivityConfig;