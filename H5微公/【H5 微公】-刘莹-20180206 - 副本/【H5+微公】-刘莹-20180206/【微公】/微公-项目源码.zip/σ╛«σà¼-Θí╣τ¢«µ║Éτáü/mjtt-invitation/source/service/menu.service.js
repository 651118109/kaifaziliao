/**
 * Created by allen on 2017/4/7.
 */

import Menu from '../models/menu';
import {ConstCode} from '../util/const';
import {ERRCODE} from '../util/errcode';
import DBHelper from '../db/mysql.connector';

class MenuService {

    constructor() {
    }

    /**
     * 获取所有菜单
     */
    getAllMenus() {
        return new Promise((resolved, rejected) => {
            return DBHelper.getConnection(ConstCode.DB_CHANNEL_BACKEND)
                .then(connection => {

                    let sql = "SELECT * FROM menu WHERE status = 0";
                    let params = [];

                    return DBHelper.query(connection, sql, params).then(result => {
                        connection.release(); // 释放链接
                        console.log("result: ", result);

                        let datas = [];
                        for (let i=0; i<result.length; i++) {
                            let menu = new Menu();
                            if ( !menu.loadFrom(result[i]) ) {
                                continue;
                            }
                            datas.push(menu);
                        }
                        resolved(datas);
                    });
                })
                .catch(err => {
                    console.error(err);
                    rejected(ERRCODE.SYSTEM_ERROR);
                });
        });
    }



}

// 导出MenuManager
export default MenuService;

