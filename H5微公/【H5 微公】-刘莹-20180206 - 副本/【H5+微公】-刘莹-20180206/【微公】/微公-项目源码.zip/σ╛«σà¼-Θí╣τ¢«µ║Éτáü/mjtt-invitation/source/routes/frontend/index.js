
import express, {Router} from 'express';
import Config from '../../../config/config.json';
import HttpClient from '../../util/http.client';
import sha1 from 'js-sha1';
import WxUser from '../../models/wx.user';
import WxUserService from '../../service/wx.user.service';
import {ERRCODE} from '../../util/errcode';
import {ConstCode} from '../../util/const';
import InvitationUtil from '../../util/invitation.util';
//import request from 'request';

let router = new Router();
let httpClient = new HttpClient();
let wxUserService = new WxUserService();
let invitationUtil = new InvitationUtil();


let getUserOpenId = (code) => {

    let url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=" 
            + Config.appId + "&secret=" + Config.appSecret + "&code="
            + code + "&grant_type=authorization_code";

    // 用户请求URL获取accessToken&openId
    return httpClient.get(url)
    .then(content => {

        return new Promise((resolved, rejected) => {

            console.log("请求accessToken&openId resp:", content);
            try {            
                content = JSON.parse(content);
            } catch (err) {
                console.error("wrong response body: ", content);
                let err = new Error("Wechat返回数据异常");
                err.status = 502;
                rejected(err);
                return ;
            }

            let errcode = content.errcode;
            let errmsg = content.errmsg;

            // 出错了
            if ( !!errcode ) {
                let err = new Error("获取accessToken&openId失败. err: " + errcode);
                err.status = 502;
                rejected(err);
                return ;
            }

            resolved(content);
        });
    })
}


/**
 * 进入活动授权页面
 */
router.get('/activityAuth', (req, res, next) => {

    console.log("[enter activityAuth] session: ", req.session);

    if (req.session && req.session.open_id) {
        //存在用户,进入活动页面
        res.redirect('/activity');
    } else {
        //进入授权页面
        let url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + Config.appId + "&redirect_uri=http://" + Config.domain + "/getopenid&response_type=code&scope=snsapi_base&state=activity#wechat_redirect";
        res.redirect(url);
    }
    
});


/**
 * 进入购买授权页面
 */
router.get('/purchaseAuth', (req, res, next) => {

    console.log("[enter purchaseAuth] session: ", req.session);

    if (req.session && req.session.open_id) {
        //存在用户,进入购买页面
        res.redirect('/purchase');
    } else {
        //进入授权页面
        let url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + Config.appId + "&redirect_uri=http://" + Config.domain + "/getopenid&response_type=code&scope=snsapi_base&state=purchase#wechat_redirect";
        res.redirect(url);
    }
});


router.get('/getopenid', (req, res, next) => {


    let code = req.query.code || "";
    let state = req.query.state || "";
    console.log("[enter getopenid] code: ", code, ", state: ", state);

    // 验证code是否合法
    if ( !code ) {
        let err = new Error('parameter error. [code] not found');
        err.status = 502;
        next(err);
        return ;
    }

    // 请求openid
    getUserOpenId(code)
    .then(result => {

        console.log("[get user openId] result: ", result);


        req.session.access_token = result.access_token;
        req.session.open_id = result.openid;
        req.session.app_id = Config.appId;
        req.session.timestamp = Config.timestamp;
        req.session.noncestr = Config.noncestr;


        res.redirect('/'+state);

    })
    .catch(err => {

        console.error("common error: ", err);
        let error = new Error(err);
        error.status = 502;
        next(err);
        return ;

    });
});

/**
 * 活动主流程
 */
router.get('/activity', (req, res, next) => {

    console.log("[enter activity] session: ", req.session);

    if ( !req.session ) {
        let err = new Error('[session] not found');
        err.status = 502;
        next(err);
        return ;
    }

    let openId = req.session.open_id;

    if ( !openId ) {
        let err = new Error('[open_id] not found');
        err.status = 502;
        next(err);
        return ;
    }

    // 计算页面签名
    let url = "http://" + Config.domain + "/activity";
    let str = "jsapi_ticket=" + global.jsapi_ticket + "&noncestr=" + Config.noncestr + "&timestamp=" + Config.timestamp + "&url=" + url;            
    let signature = sha1(str);

    // 用户是否开始活动
    // 未开始，则渲染页面（需要banner图片地址和活动介绍内容） 
    // 已开始，则通知活动页面自动跳转到freecard，自动进入公众号窗口。
    wxUserService.get(openId)
    .then(user => {

        console.log("get user => ", user);

        // 用户不存在，添加用户
        if ( user == null ) {

            res.render('frontend/activity.ejs', { 
                title: '美景听听邀请卡', 
                signature: signature,
                banner: global.activity.banner
            });

            let current = new Date().getTime();
            let wxUser = new WxUser();
            wxUser.openId = openId;
            wxUser.created = current;
            wxUser.updated = current;
            
            console.log("add user : ", wxUser);                
            wxUserService.add(wxUser)
             .then(result => {
                console.log("result for add user: ", result);
            });

        } else {
            if (user.status != ConstCode.ACTIVITY_NOT_APPLY) {
                res.render('frontend/closewindow.ejs', { 
                    title: '美景听听邀请卡', 
                    signature: signature,
                });

            } else {
                res.render('frontend/activity.ejs', { 
                    title: '美景听听邀请卡', 
                    signature: signature,
                    banner: global.activity.banner
                });
            }                        
        }
    })
    .catch(err => {

        console.error("error: ", err);
        let error = new Error(err);
        error.status = 502;
        next(err);
        return ;

    });

});

/**
 * 邀请码购买
 */
router.get('/purchase', (req, res, next) => {

    if ( !req.session ) {
        let err = new Error('[session] not found');
        err.status = 502;
        next(err);
        return ;
    }

    if ( !req.session.open_id ) {
        let err = new Error('[open_id] not found');
        err.status = 502;
        next(err);
        return ;
    }

    // 渲染购买页面
    let url = "http://" + Config.domain + "/purchase";
    let str = "jsapi_ticket=" + global.jsapi_ticket + "&noncestr=" + Config.noncestr + "&timestamp=" + Config.timestamp + "&url=" + url;            
    let signature = sha1(str);
    console.log("purchase url: ", url, ", signature str: ", str, ", sign: ", signature);

    res.render('frontend/purchase.ejs', { 
        title: '购买邀请码',
        signature: signature,
        price: global.activity.price,
        banner: global.activity.banner
    });

})

/**
 * 申请邀请码
 */
router.get('/freecard', (req, res, next) => {

    console.log("[Enter Freecard] session: ", req.session);

    if ( !req.session || !req.session.open_id) {
        console.error("wrong openId.");
        return res.json({
            code: 501,
            result: {
                message: "用户无效"
            }
        });
    }

    res.json({                  
        code: 200,
        result: {
            message: '自动关闭窗口',
            msg: ''
        }
    });

    invitationUtil.Enter(req.session.open_id);
    
});



module.exports = router;