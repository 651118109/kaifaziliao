import express, {Router} from 'express';
import {ERRCODE} from '../../util/errcode';
import {ConstCode} from '../../util/const';
import CommonUtil from '../../util/common.util';
import Admin from '../../models/admin';
import AdminService from '../../service/admin.service';

let router = new Router();
let adminService = new AdminService();
let commonUtil = new CommonUtil();

/**
 * 获取管理员列表
 */
router.get('/list', (req, res, next) => {

    let count = req.query.count || ConstCode.PAGE_DEFAULT_COUNT;
    let page = req.query.page || 1; // 当前页（默认从1开始）
    let searchContent = req.query.searchContent || ""; // 搜索内容信息

    // 返回数据包
    let resp = {
        code:ERRCODE.SUCCESS,
        data: {}
    };

    page = parseInt(page);
    Promise.all([
        adminService.searchWithPaginator(page, count, searchContent),
        adminService.getSizeWithContent(searchContent)
    ]).then(results => {
       console.log("results: ", results);
       resp.data = {
           admins: results[0],
           paginator: commonUtil.genPaginator(page, results[1], count),
           search: {
               content: searchContent
           }
       };
       resp.data.paginator.curPage = page;
       res.json(resp);
    }).catch(err => {
        resp.code = err;
        return res.json(resp);
    });
});

/**
 * 添加管理员
 */
router.post('/add', (req, res, next) => {

    // 获取提交的参数
    let roleId = req.body.roleId || 0;
    let username = req.body.username || "";
    let password = req.body.password || "";

    // step0: 校验参数
    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    adminService.getByUsername(username).then(result => {
        resp.code = ERRCODE.USER_ALREADY_EXISTS_ERROR;
        return res.json(resp);
    }).catch( err => {

        if ( err === ERRCODE.USER_NOT_EXISTS_ERROR ) { // 找不到该用户
            let admin = new Admin();
            admin.roleId = roleId;
            admin.username = username;
            admin.setPassword(password);// 由admin来决定加密的方式
            let current = new Date().getTime();
            admin.created = current;
            admin.updated = current;

            // 添加用户
            adminService.add(admin).then( result => {
                if ( !result.insertId ) {
                    resp.code = ERRCODE.SYSTEM_ERROR;
                    return res.json(resp);
                }
                res.jsonp(resp);

            }).catch( err => {
                console.error("add admin error: ", err);
                resp.code = ERRCODE.SYSTEM_ERROR;
                return res.json(resp);
            });
        } else {
            resp.code = ERRCODE.SYSTEM_ERROR;
        }
        return res.json(resp);
    });
});

/**
 * 编辑管理员
 */
router.post('/edit', (req, res, next) => {

    let adminId = req.body.adminId || 0;
    let roleId = req.body.roleId || 0;
    let username = req.body.username || "";

    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    // 获取admin的信息
    let admin = null;
    adminService.getById(adminId).then( data => {
        admin = data;
        admin.roleId = roleId;
        admin.username = username;

        // 修改admin的信息
        return adminService.modify(admin);
    }).then( result => {
        // 修改成功
        console.log("admin edit result: ", result);
        res.json(resp);
    }).catch(err => {
        resp.code = err;
        return res.json(resp);
    });

});

/**
 * 删除管理员
 */
router.post('/del', (req, res, next) => {

    let adminId = req.body.itemId || 0;
    let resp = {
        code: ERRCODE.SUCCESS,
        data: {}
    };

    // 删除记录
    adminService.delById(adminId)
    .then( result => {
        console.log("admin del result: ", result);
        res.json(resp);
    })
    .catch( err => {
        resp.code = err;
        return res.json(resp);
    });

});

module.exports = router;