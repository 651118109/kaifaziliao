/**
 * Created by allen on 2017/4/5.
 * 封装表格数据刷新接口
 */

/**
 * 通过ajax获取url中的数据
 * 如果method是GET，需要将params数据组装为queryString
 * @param url
 * @param params {Dict}
 * @param method {"GET" | "POST"}
 * @param callback {err, datas}
 */
function load_table_content(url, params, method, callback) {

    // 构建参数
    let data = {};
    if ( method === "GET" ) {
        let queryString = buildQueryParam(params);
        if ( queryString != "" ) {
            url = url + "?" + queryString;
        }
    } else {
        data = params;
    }

    $.ajax({
        url: url,
        type: method,
        data: data,
        dataType: 'json',
        success: function (result) {
            console.log("result: ", result);
            if (result.code !== ERRCODE.SUCCESS ) {
                return callback(result.code, null);
            }
            return callback(result.code, result.data);
        },
        error: function (result) {
            console.error("ajax error: ", result.responseText);
            return callback(ERRCODE.SYSTEM_ERROR, null);
        }
    });
}

// 返回表格行对象
function get_content_line() {
    return $('<tr>');
}

/**
 * 返回表格单元格对象
 * @param content 单元格内容
 * @param 单元格属性
 */
function get_content_cell(content, attributes) {
    return $('<td>').html(content);
}

/**
 * 获取图片表格
 * @param content
 * @param attributes
 * @returns {jQuery}
 */
function get_image_content_cell(content, attributes) {
    return $('<td>').html(
        $('<img>').attr("src", content).css("width", attributes.width).css("height", attributes.height)
    );
}

// 返回编辑按钮
function get_edit_button() {
    return $('<button class="btn btn-sm btn-primary">').html(
        $("<i class='fa fa-pencil'>")
    ).attr("alt", "编辑").attr("title", "编辑");
}

// 返回删除按钮
function get_del_button() {
    return $('<button class="btn btn-sm btn-danger">').html(
        $("<i class='fa fa-trash'>")
    ).attr("alt", "编辑").attr("title", "删除");
}

/**
 * 返回primary格式的文本按钮
 * @param text
 */
function get_primary_text_button(text) {
    return $('<button class="btn btn-sm btn-primary">').text(text);
}

/**
 * 返回danger格式的文本按钮
 * @param text
 */
function get_danger_text_button(text) {
    return $('<button class="btn btn-sm btn-danger">').text(text);
}


// 返回分页按钮
function get_paginator_buttons(cur_page, page_size, prev_page, next_page) {
    let buttons = [];
    buttons.push($('<button class="btn btn-sm btn-default">').attr("page", prev_page).html("上一页"));
    if ( page_size <= 5 ) { // 小于5页时，页码全部显示
        for (let i=1; i<=page_size; i++) {
            let cls = "btn btn-sm btn-default";
            if ( cur_page === i ) {
                cls = "btn btn-sm btn-primary";
            }
            buttons.push($('<button class="' + cls + '">').attr("page", i).html(i));
        }
    } else { // 大于5页时，页面显示首尾各2页
        // 首2页
        for (let i=1; i<=2; i++) {
            let cls = "btn btn-sm btn-default";
            if ( cur_page === i ) {
                cls = "btn btn-sm btn-primary";
            }
            buttons.push($('<button class="' + cls + '">').attr("page", i).html(i));
        }
        buttons.push($('<button class="btn btn-sm btn-default">').attr("disabled", disabled).html("..."));
        // 尾2页
        for (let i=page_size - 1; i<=page_size; i++) {
            let cls = "btn btn-sm btn-default";
            if ( cur_page === i ) {
                cls = "btn btn-sm btn-primary";
            }
            buttons.push($('<button class="' + cls + '">').attr("page", i).html(i));
        }
    }
    buttons.push($('<button class="btn btn-sm btn-default">').attr("page", next_page).html("下一页"));
    return buttons;
}