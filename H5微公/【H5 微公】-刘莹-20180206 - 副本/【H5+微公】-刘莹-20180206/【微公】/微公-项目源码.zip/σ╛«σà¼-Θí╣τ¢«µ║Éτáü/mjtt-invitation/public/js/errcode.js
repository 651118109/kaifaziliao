
// 定义错误码

let ERRCODE = {
    SUCCESS: 0,             // 成功

    PARAMETER_ERROR: 1001,             // 传入参数错误
    SYSTEM_ERROR: 1002,                // 系统未知错误

    USER_NOT_EXISTS_ERROR: 2001,       // 用户不存在
    PASSWORD_NOT_CORRECT_ERROR: 2002,  // 密码不正确
    USER_ALREADY_EXISTS_ERROR: 2003,   // 用户已存在
};