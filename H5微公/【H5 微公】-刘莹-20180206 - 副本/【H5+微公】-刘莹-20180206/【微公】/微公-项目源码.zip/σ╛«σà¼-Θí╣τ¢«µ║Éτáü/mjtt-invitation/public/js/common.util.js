/**
 * 将params组合为一个queryString格式的字符串
 * @param params
 */
function buildQueryParam(params) {
    if (!params) {
        console.error("build query params is empty!!");
        return "";
    }
    let paramStr = "";
    for (let param in params) {
        paramStr += param + "=" + params[param] + "&"
    }
    // 截取尾端多余的&
    paramStr.substr(0, paramStr.length - 1);
    console.log("param str: ", paramStr);
    return paramStr;
}

/**
 * 显示错误的toastr信息
 * @param content
 */
function showError(content) {
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-full-width",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    // 不显示title
    toastr.error(content);
};

/**
 * 显示成功信息
 * @param content
 */
function showSuccess(content) {
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-full-width",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    toastr.success(content);
};

/**
 * 显示通知信息
 * @param content
 */
function showInfo(content) {
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-full-width",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    toastr.info(content);
}