### 微信公众号部署文档

#### 服务器地址

当前服务部署在 

```47.93.116.216 22```

数据库在同个服务器。

账号密码为 ```develop/develop``` 数据库名称为 ```mjtt_invitation```

#### 图片上传CDN

目前使用的为青柠智云的七牛CDN存储空间，请在半年内转换为贵司自己的CDN存储。

#### Step 1

进入到代码根目录。执行 ```npm install``` 完成依赖组件的安装

#### Step 2

执行 ```pm2 restart/start``` 命令启动对应的服务。此处为 ```pm2 restart mjtt-invitation``` 执行 ```pm2 list``` 查看服务是否正常

Tips:

pm2 类似于 supervisor。是一个进程管理工具，相关内容可参考 [http://pm2.keymetrics.io/](http://pm2.keymetrics.io/)

整个代码基于 nodejs 的 es6以上版本语法编写，相关的打包等技术需要自行参考。使用到了 babel, gulp 等技术

